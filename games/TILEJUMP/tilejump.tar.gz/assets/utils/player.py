import pygame, os
from .spritesheet import SpriteSheet

class Sword:
    def __init__(self):
        self.sprite_right = pygame.image.load(os.path.join('assets','sprites','sword.png'))
        self.sprite_left = pygame.transform.flip(self.sprite_right,True,False)
        self.size = pygame.Vector2(16,10)
        self.rect = None

    def get_sword(self,pos,offset):
        self.rect = pygame.Rect(pos,self.size)
        self.draw_rect = self.rect.copy()
        self.draw_rect.left -= offset.x
        self.draw_rect.y += 2
        self.draw_dest = self.draw_rect.topleft
        
#122
class Player:
    def __init__(self):
        self.hp = 5
        self.alive = True
        self.pos = pygame.Vector2(122, 136)
        self.sprite_adjustment_right = pygame.Vector2(2,8)
        self.sprite_adjustment_left = pygame.Vector2(6,8)
        self.vel = pygame.Vector2(0, 0)
        self.speed = 1.5
        self.jump_height = 4
        self.knockback = 0
        self.knocked = False
        self.damaged = False
        self.damage_time = 0
        self.friction = 0.4
        self.gravity = 0.2
        self.on_ground = False
        self.atack = 'none'
        self.atack_released = True
        self.actacking = False
        self.atack_on_cooldown = False
        self.sword = Sword()
        self.sword_pos = pygame.Vector2(0,0)
        self.sword_sprite = self.sword.sprite_right
        self.rect = pygame.Rect(self.pos, (14, 24))
        self.player_sprite_sheet = os.path.join('assets', 'sprites', 'player.png')

        self.atack_time = pygame.time.get_ticks()
        self.start_time = pygame.time.get_ticks()

        self.player_sprites_right = SpriteSheet(
            self.player_sprite_sheet, 8, 22, 32).get_sprites()
        self.player_sprites_left = [pygame.transform.flip(
            sprite, True, False) for sprite in self.player_sprites_right]
        self.player_sprite_dirrection = self.player_sprites_right
        self.walk_frame = 0
        self.moving = False

    def handle_inputs(self, inputs):
        self.moving = False
        if inputs[pygame.K_RIGHT]:
            self.vel.x += self.speed
            self.player_sprite_dirrection = self.player_sprites_right
            self.atack = 'right'
            self.moving = True
        if inputs[pygame.K_LEFT]:
            self.vel.x -= self.speed
            self.player_sprite_dirrection = self.player_sprites_left
            self.atack = 'left'
            self.moving = True
        if inputs[pygame.K_UP] and self.on_ground:
            self.vel.y = -self.jump_height
        
        if not inputs[pygame.K_x]:
            self.atack_released = True

        if inputs[pygame.K_x] and self.atack_released:
            if not self.actacking and not self.atack_on_cooldown:
                self.actacking = True
                self.atack_released = False
                self.atack_time = pygame.time.get_ticks()

    def update(self,platforms,enemy,boss,offset):
        self.vel.y += self.gravity


        if self.rect.x < 948:
            if self.knockback > 0:
                if self.rect.centerx <= enemy.rect.centerx:
                    self.knockback -= self.friction
                    self.vel.x -= self.knockback
                elif self.rect.centerx > enemy.rect.centerx:
                    self.knockback -= self.friction
                    self.vel.x += self.knockback
                if self.on_ground and self.knocked:
                        self.vel.y = -1
                        self.knocked = False
            else:
                self.knockback = 0

        if self.rect.x > 950:
            if self.knockback > 0:
                if self.rect.centerx <= boss.rect.centerx:
                    self.knockback -= self.friction
                    self.vel.x -= self.knockback
                elif self.rect.centerx > boss.rect.centerx:
                    self.knockback -= self.friction
                    self.vel.x += self.knockback
                if self.on_ground and self.knocked:
                        self.vel.y = -1
                        self.knocked = False
            else:
                self.knockback = 0

        self.pos.x += self.vel.x
        self.rect.x = self.pos.x


        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.x > 0:
                self.rect.right = platform.left
            if self.vel.x < 0:
                self.rect.left = platform.right
            self.pos.x = self.rect.x

        self.pos.y += self.vel.y
        self.rect.y = self.pos.y

        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.y > 0:
                self.rect.bottom = platform.top
            if self.vel.y < 0:
                self.rect.top = platform.bottom

            if self.rect.bottom == platform.top:
                self.on_ground = True
                self.vel.y = 0
            else: 
                self.on_ground = False
            self.pos.y = self.rect.y
        else:
            self.on_ground = False

        self.sword_pos = pygame.Vector2(self.rect.right,self.rect.y+10)

        if self.actacking:
            if (0 <= pygame.time.get_ticks() - self.atack_time < 300):
                if self.atack == 'right':
                    self.sword_pos = pygame.Vector2(self.rect.right,self.rect.y+10)
                    self.sword_sprite = self.sword.sprite_right
                elif self.atack == 'left':
                    self.sword_pos = pygame.Vector2(self.rect.right-30,self.rect.y+10)
                    self.sword_sprite = self.sword.sprite_left
                self.sword.get_sword(self.sword_pos,offset)
            else:
                self.actacking = False
                self.atack_on_cooldown = True

        
        
        if self.atack_on_cooldown:
            if pygame.time.get_ticks() - self.atack_time > 500:
                self.atack_on_cooldown = False

        

        self.vel.x = 0

        if enemy.alive:
            if self.rect.colliderect(enemy.rect):
                self.knockback = 6
                self.knocked = True
                if not self.damaged:
                    self.hp -= 1
                    self.damaged = True
                    self.damage_time = pygame.time.get_ticks()

        if boss.alive:
            if self.rect.colliderect(boss.rect):
                self.knockback = 4
                self.knocked = True
                if not self.damaged:
                    self.hp -= 1
                    self.damaged = True
                    self.damage_time = pygame.time.get_ticks()

        if self.damaged:
            if pygame.time.get_ticks() - self.damage_time >= 250:
                self.damaged = False
                self.damage_time = 0

        if self.hp <= 0 :
            self.alive = False
        

    def draw(self, surf, offset):
        offset_rect = self.rect.copy()
        offset_rect.left = offset_rect.left - offset.x
        #pygame.draw.rect(surf, (255, 100, 100), offset_rect)

        self.sword.get_sword(self.sword_pos,offset)

        self.player_draw_location = (
            self.pos - self.sprite_adjustment_right - offset) if self.player_sprite_dirrection == self.player_sprites_right else self.pos - self.sprite_adjustment_left - offset

        if self.moving:
            step_duration = pygame.time.get_ticks() - self.start_time
            if step_duration > 100:
                self.start_time = pygame.time.get_ticks()
                self.walk_frame += 1
                if self.walk_frame > (len(self.player_sprite_dirrection)-1):
                    self.walk_frame = 0

        if not self.moving:
            last_step_duration = pygame.time.get_ticks() - self.start_time
            if last_step_duration > 100:
                self.start_time = pygame.time.get_ticks()
                if self.walk_frame > 4:
                    self.walk_frame = 4
                else:
                    self.walk_frame = 0

        surf.blit(self.player_sprite_dirrection[self.walk_frame],self.player_draw_location)
            

        if self.actacking:

            #pygame.draw.rect(surf,(100,100,200),((self.sword_pos.x-offset.x,self.sword_pos.y),self.sword.size))

            surf.blit(self.sword_sprite,self.sword.draw_dest)