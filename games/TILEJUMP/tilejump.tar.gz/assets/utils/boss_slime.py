import pygame, os
from .spritesheet import SpriteSheet
from .slime import Slime


class Boss_slime(Slime):
    def __init__(self):
        super().__init__()
        self.hp = 30

        self.pos = pygame.Vector2(1120, 115)
        self.sprite_adjustment_right = pygame.Vector2(10,10)
        self.sprite_adjustment_left = pygame.Vector2(4,10)

        self.gravity = 0.1

        self.rect = pygame.Rect(self.pos, (65, 50))

        self.boss_clock = pygame.time.get_ticks()
        self.boss_move = 0

        self.player_sprite_sheet = os.path.join('assets', 'sprites', 'boss_slime.png')
        self.player_sprites_right = SpriteSheet(
            self.player_sprite_sheet, 5, 78, 60).get_sprites()
        self.player_sprites_left = [pygame.transform.flip(
            sprite, True, False) for sprite in self.player_sprites_right]
        self.player_sprite_dirrection = self.player_sprites_left

    def move(self,player):
        if self.boss_move == 0:
            if pygame.time.get_ticks() - self.boss_clock > 500:
                self.boss_clock = pygame.time.get_ticks()
                self.walk_frame = 1
                self.boss_move = 1
        if self.boss_move == 1:
            if pygame.time.get_ticks() - self.boss_clock > 500:
                self.boss_clock = pygame.time.get_ticks()
                self.walk_frame = 2
                self.boss_move = 2
        if self.boss_move == 2:
            if pygame.time.get_ticks() - self.boss_clock > 500:
                self.boss_clock = pygame.time.get_ticks()
                self.walk_frame = 3
                self.boss_move = 3

                self.vel.y = -3
                if player.rect.centerx <= self.rect.centerx:
                    self.vel.x = -1
                if player.rect.centerx > self.rect.centerx:
                    self.vel.x = 1

        if self.boss_move == 3:
            if pygame.time.get_ticks() - self.boss_clock > 500:
                self.boss_clock = pygame.time.get_ticks()
                self.walk_frame = 4
                self.boss_move = 4

        if self.boss_move == 4:
            if pygame.time.get_ticks() - self.boss_clock > 500:
                self.boss_clock = pygame.time.get_ticks()
                self.walk_frame = 0
                self.boss_move = 0



    def update(self,platforms,player):
        if player.rect.x > 946:
            self.move(player)

        if player.rect.centerx <= self.rect.centerx:
            self.player_sprite_dirrection = self.player_sprites_left
        if player.rect.centerx > self.rect.centerx:
            self.player_sprite_dirrection = self.player_sprites_right


        self.vel.y += self.gravity

        self.pos.x += self.vel.x
        self.rect.x = self.pos.x


        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.x > 0:
                self.rect.right = platform.left
            if self.vel.x < 0:
                self.rect.left = platform.right
            self.pos.x = self.rect.x

        self.pos.y += self.vel.y
        self.rect.y = self.pos.y

        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.y > 0:
                self.rect.bottom = platform.top
            if self.vel.y < 0:
                self.rect.top = platform.bottom

            if self.rect.bottom == platform.top:
                self.on_ground = True
                self.vel.y = 0
            else: 
                self.on_ground = False
            self.pos.y = self.rect.y
        else:
            self.on_ground = False

        if self.on_ground:
            self.vel.x = 0

        if player.alive:
            if player.actacking:
                if self.rect.colliderect(player.sword.rect):
                    if not self.damaged:
                        self.hp -= 1
                        self.damaged = True
                        self.damage_time = pygame.time.get_ticks()

        if self.damaged:
            if pygame.time.get_ticks() - self.damage_time >= 250:
                self.damaged = False
                self.damage_time = 0

        if self.hp <= 0 :
            self.alive = False

    def draw(self, surf, offset):
        offset_rect = self.rect.copy()
        offset_rect.left = offset_rect.left - offset.x
        #pygame.draw.rect(surf, (255, 100, 100), offset_rect)

        self.player_draw_location = (
            self.pos - self.sprite_adjustment_right - offset) if self.player_sprite_dirrection == self.player_sprites_right else self.pos - self.sprite_adjustment_left - offset

        surf.blit(self.player_sprite_dirrection[self.walk_frame],self.player_draw_location)

        #pygame.draw.rect(surf, (255, 100, 100), offset_rect)
