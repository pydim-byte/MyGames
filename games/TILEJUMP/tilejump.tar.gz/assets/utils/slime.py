import pygame, os
from .spritesheet import SpriteSheet

class Slime:
    def __init__(self):
        self.hp = 3
        self.alive = True
        self.pos = pygame.Vector2(800, 145)
        self.sprite_adjustment_right = pygame.Vector2(4,4)
        self.sprite_adjustment_left = pygame.Vector2(2,4)
        self.vel = pygame.Vector2(0, 0)
        self.speed = 1.5
        self.jump_height = 4
        self.knockback = 0
        self.knocked = False
        self.damaged = False
        self.damage_time = 0
        self.gravity = 0.2
        self.friction = 0.4
        self.on_ground = False
        self.rect = pygame.Rect(self.pos, (20, 15))
        self.player_sprite_sheet = os.path.join('assets', 'sprites', 'slime.png')

        self.start_time = pygame.time.get_ticks()

        self.player_sprites_right = SpriteSheet(
            self.player_sprite_sheet, 4, 26, 20).get_sprites()
        self.player_sprites_left = [pygame.transform.flip(
            sprite, True, False) for sprite in self.player_sprites_right]
        self.player_sprite_dirrection = self.player_sprites_right
        self.walk_frame = 0
        self.moving = False
        self.dirrection = 'left'

    def move(self):
        if self.rect.x >= 800:
            self.dirrection = 'left'
        if self.rect.x <=672:
            self.dirrection = 'right'

        if self.dirrection == 'left':
            self.vel.x -= 1
            self.player_sprite_dirrection = self.player_sprites_left
            self.moving = True
        if self.dirrection == 'right':
            self.vel.x += 1
            self.player_sprite_dirrection = self.player_sprites_right
            self.moving = True


    def update(self,platforms,player):
        self.move()
        self.vel.y += self.gravity

        if self.knockback > 0:
            if self.rect.centerx <= player.rect.centerx:
                self.knockback -= self.friction
                self.vel.x -= self.knockback
            elif self.rect.centerx > player.rect.centerx:
                self.knockback -= self.friction
                self.vel.x += self.knockback
            if self.on_ground and self.knocked:
                    self.vel.y = -1
                    self.knocked = False
        else:
            self.knockback = 0

        self.pos.x += self.vel.x
        self.rect.x = self.pos.x


        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.x > 0:
                self.rect.right = platform.left
            if self.vel.x < 0:
                self.rect.left = platform.right
            self.pos.x = self.rect.x

        self.pos.y += self.vel.y
        self.rect.y = self.pos.y

        if self.rect.collidelist(platforms) != -1:
            platform = platforms[self.rect.collidelist(platforms)] 
            if self.vel.y > 0:
                self.rect.bottom = platform.top
            if self.vel.y < 0:
                self.rect.top = platform.bottom

            if self.rect.bottom == platform.top:
                self.on_ground = True
                self.vel.y = 0
            else: 
                self.on_ground = False
            self.pos.y = self.rect.y
        else:
            self.on_ground = False

        self.vel.x = 0

        if player.alive:
            if player.actacking:
                if self.rect.colliderect(player.sword.rect):
                    self.knockback = 6
                    self.knocked = True
                    if not self.damaged:
                        self.hp -= 1
                        self.damaged = True
                        self.damage_time = pygame.time.get_ticks()

        if self.damaged:
            if pygame.time.get_ticks() - self.damage_time >= 250:
                self.damaged = False
                self.damage_time = 0

        if self.hp <= 0 :
            self.alive = False

    def draw(self, surf, offset):
        offset_rect = self.rect.copy()
        offset_rect.left = offset_rect.left - offset.x
        #pygame.draw.rect(surf, (255, 100, 100), offset_rect)

        self.player_draw_location = (
            self.pos - self.sprite_adjustment_right - offset) if self.player_sprite_dirrection == self.player_sprites_right else self.pos - self.sprite_adjustment_left - offset

        if self.moving:
            step_duration = pygame.time.get_ticks() - self.start_time
            if step_duration > 100:
                self.start_time = pygame.time.get_ticks()
                self.walk_frame += 1
                if self.walk_frame > (len(self.player_sprite_dirrection)-1):
                    self.walk_frame = 0

        if not self.moving:
            last_step_duration = pygame.time.get_ticks() - self.start_time
            if last_step_duration > 100:
                self.start_time = pygame.time.get_ticks()
                self.walk_frame = 0

        surf.blit(self.player_sprite_dirrection[self.walk_frame],self.player_draw_location)

        #pygame.draw.rect(surf, (255, 100, 100), offset_rect)

        
