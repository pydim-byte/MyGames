import pygame
from pytmx.util_pygame import load_pygame

class Tile(pygame.sprite.Sprite):
    def __init__(self,pos,surf,groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft = pos)


class TileMap:
    def __init__(self,map):
        self.map_sprites = pygame.sprite.Group()
        self.platforms = []


        level = load_pygame(map)


        for layer in level.visible_layers:
            if hasattr(layer, 'data'):
                for x, y, surf in layer.tiles():
                    pos = (x*4, y*4)
                    Tile(pos=pos, surf=surf, groups=self.map_sprites)

        for obj in level.objects:
            if obj.type == 'platform':
                self.platforms.append(pygame.Rect(obj.x, obj.y, obj.width, obj.height))
            if obj.type == 'normal_level_wall':
                self.__setattr__('normal_level_wall',pygame.Rect(obj.x, obj.y, obj.width, obj.height))
            if obj.type == 'boss_wall':
                self.__setattr__('boss_wall',pygame.Rect(obj.x, obj.y, obj.width, obj.height))