# /// script
# dependencies = [
#   "pygame_gui",
#   "python-i18n",
# ]
# ///
import pygame,os,sys, asyncio
import pygame_gui
from pygame_gui.core import ObjectID


SCREEN_WIDTH,SCREEN_HEIGHT = 800,600
FPS = 60


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.canvas = pygame.Surface((800,600))
        self.canvas.fill("#FFFFFF")
        self.ui_manager = pygame_gui.UIManager((SCREEN_WIDTH,SCREEN_HEIGHT),theme_path='theme.json')
        self.tools_panel = pygame_gui.elements.UIPanel(relative_rect=pygame.Rect((600,0),(200,600)),
                                                       manager=self.ui_manager)
        self.clock = pygame.Clock()
        self.draw_colour = "#FF0000"
        
        self.colours = {'black' : '#000000','white' : '#FFFFFF','red' : '#FF0000','blue' : '#1900FF',
                        'yellow' : '#E5FF00','orange' :'#FF8400','green' : '#00FF37','purple' : '#BB00FF'}

        self.color_buttons = {}

        self.place_buttons()

        


    def place_buttons(self):
        for i, (name, color) in enumerate(self.colours.items()):
            pos = (40 + 80*(i % 2), 20 + 80*(i // 2))
            btn = pygame_gui.elements.UIButton(
                relative_rect=pygame.Rect(pos, (40, 40)),
                text='',
                container=self.tools_panel,
                manager=self.ui_manager
            )

            # Set button colors dynamically (game-style)
            btn.colours['normal_bg'] = pygame.Color(color)
            btn.colours['hovered_bg'] = pygame.Color(color)
            btn.colours['active_bg'] = pygame.Color(color)
            btn.colours['normal_border'] = pygame.Color('#000000')
            btn.rebuild()

            # Map the button object to the color it represents
            self.color_buttons[btn] = color       

    def handle_inputs(self,inputs):
        pass

    def update(self,dt):
        pass

    def draw(self):
        self.screen.fill("#FFFFFF")
        self.screen.blit(self.canvas,(0,0))
        self.ui_manager.draw_ui(self.screen)
        pygame.display.flip()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element in self.color_buttons:
                        self.draw_colour = self.color_buttons[event.ui_element]

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        pos = event.pos
                        pygame.draw.circle(self.canvas,self.draw_colour,pos,2.5)

                if event.type == pygame.MOUSEMOTION:
                    pos, rel = event.pos, event.rel

                    if event.buttons[0]:
                        pygame.draw.line(self.canvas,self.draw_colour,pos,(pos[0]-rel[0],pos[1]-rel[1]),5)

                self.ui_manager.process_events(event)


            

            dt = self.clock.tick(FPS)/1000

            self.ui_manager.update(dt)

            self.draw()

            await asyncio.sleep(0)
            
game = Game()
asyncio.run(game.run())