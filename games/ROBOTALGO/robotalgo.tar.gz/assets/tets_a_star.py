import pygame
from noise import pnoise1

pygame.init()

WIDTH, HEIGHT = 800, 600
BLOCK_SIZE = 20

COLS = WIDTH // BLOCK_SIZE
ROWS = HEIGHT // BLOCK_SIZE

screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Noise settings
scale = 0.08
amplitude = 8      # Height variation (in blocks)
base_height = 15   # Average ground height (in blocks)

offset = 0  # for scrolling

running = True
while running:
    clock.tick(60)
    screen.fill((135, 206, 235))  # Sky

    offset += 0.02  # Scroll speed

    for col in range(COLS):
        world_x = col + offset

        noise_val = pnoise1(world_x * scale, octaves=4)
        height = int(noise_val * amplitude + base_height)

        for row in range(height, ROWS):
            rect = pygame.Rect(
                col * BLOCK_SIZE,
                row * BLOCK_SIZE,
                BLOCK_SIZE,
                BLOCK_SIZE
            )

            # Simple layering
            if row == height:
                color = (34, 139, 34)  # grass
            elif row < height + 3:
                color = (139, 69, 19)  # dirt
            else:
                color = (100, 100, 100)  # stone

            pygame.draw.rect(screen, color, rect)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()

pygame.quit()
