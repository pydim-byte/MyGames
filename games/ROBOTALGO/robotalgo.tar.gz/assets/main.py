import pygame,os,sys,random, asyncio
from queue import Queue
import copy
import heapq
from dataclasses import dataclass

import traceback


SCREEN_WIDTH, SCREEN_HEIGHT = 800,600
FPS = 60
GRID_SIZE = 20
GRID_WIDTH = SCREEN_WIDTH // GRID_SIZE
GRID_HEIGHT = SCREEN_HEIGHT // GRID_SIZE
MAP = [[1 for x in range(GRID_WIDTH)] for y in range(GRID_HEIGHT)]


# HELPER FUNCTIONS STARTS

def pixel_to_grid(pos):
    return pos[0] // GRID_SIZE, pos[1] // GRID_SIZE

def grid_to_pixel_center(cell):
    return pygame.Rect(cell[0] * GRID_SIZE,cell[1] * GRID_SIZE,GRID_SIZE,GRID_SIZE).center

# HELPER FUNCTIONS ENDS



class Drunkards:
    def __init__(self):
        self.start = [GRID_WIDTH // 2, GRID_HEIGHT // 2]
        self.moves = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        self.game_map = copy.deepcopy(MAP)

    def walk(self):
        x,y = self.start
        self.path = Queue()
        self.path.put(self.start)
        steps = random.randint((GRID_WIDTH*GRID_HEIGHT)//2,
                               GRID_WIDTH*GRID_HEIGHT)
        for _ in range(steps):
            dx, dy = random.choice(self.moves)
            x += dx
            y += dy
            x = max(0, min(x, GRID_WIDTH-1))
            y = max(0, min(y, GRID_HEIGHT-1))
            self.game_map[y][x] = 0
            self.path.put((x,y))

        return self.path

@dataclass
class CellInfo:
    f : float = float('inf')
    g : float = float('inf')
    h : float = float('inf')
    x : int = -1
    y : int = -1

class AStar:
    # A* algorythm represented by formula below
    # f(n) = g(n) + h(n), where
    # f(n) - total cost
    # g(n) - path cost
    # h(n) - heuristic, for our case represented by octile distance
    def __init__(self,game_map):
        self.map = game_map    
        self.map_width =  len(self.map[0])
        self.map_height = len(self.map)        

    def is_valid(self,x,y):
        return (0 <= x <= self.map_width-1) and (0 <= y <= self.map_height-1)

    def is_unblocked(self,x,y):
        return self.map[y][x] == 0

    def goal_reached(self,x,y,goal):
        return x == goal[0] and y == goal[1]

    def octile_distance(self, a, b):
        dx = abs(a[0] - b[0])
        dy = abs(a[1] - b[1])
        return (dx + dy) + (1.414 - 2) * min(dx, dy)

    # from the tutorial where row=i and col =j
    # in my system row=y and col=x
    # so adapting it would be y=i and x=j
    def get_path(self,start,goal):
        x = start[0] 
        y = start[1]

        goal_x = goal[0] 
        goal_y = goal[1] 

        if not self.is_unblocked(goal_x, goal_y):
            return

        if self.goal_reached(x,y,(goal_x,goal_y)):
            return
        
        closed_list = [[False for _ in range(self.map_width)] for _ in range(self.map_height)]
        cell_details = [[CellInfo() for _ in range(self.map_width)] for _ in range(self.map_height)]    
        
        cell_details[y][x].f = 0
        cell_details[y][x].g = 0
        cell_details[y][x].h = 0
        cell_details[y][x].y = y
        cell_details[y][x].x = x
        
        open_list = []
        heapq.heappush(open_list, (0.0, 0.0, y, x))

        while open_list:
            _, _, y, x = heapq.heappop(open_list)

            if closed_list[y][x]:
                continue

            closed_list[y][x] = True

            directions = [(0, 1), (0, -1), (1, 0), (-1, 0),
                        (1, 1), (1, -1), (-1, 1), (-1, -1)]
            
            for dir in directions:
                new_y = y + dir[0]
                new_x = x + dir[1]

                # Prevent corner cutting
                if dir[0] != 0 and dir[1] != 0:
                    adj1_x, adj1_y = x + dir[1], y
                    adj2_x, adj2_y = x, y + dir[0]

                    if not (
                        self.is_valid(adj1_x, adj1_y) and
                        self.is_valid(adj2_x, adj2_y) and
                        self.is_unblocked(adj1_x, adj1_y) and
                        self.is_unblocked(adj2_x, adj2_y)
                    ):
                        continue

                if not self.is_valid(new_x, new_y):
                    continue
                if not self.is_unblocked(new_x, new_y):
                    continue
                if closed_list[new_y][new_x]:
                    continue

                if self.goal_reached(new_x, new_y, (goal_x, goal_y)):
                    cell_details[new_y][new_x].x = x
                    cell_details[new_y][new_x].y = y
                    return self.trace_path(cell_details, [new_x, new_y])
                else:
                    if dir[0] != 0 and dir[1] != 0:
                        g_new = cell_details[y][x].g + 1.414  # diagonal
                    else:
                        g_new = cell_details[y][x].g + 1.0    # straight
                    h_new = self.octile_distance([new_x,new_y], [goal_x,goal_y])
                    f_new = g_new + h_new

                    if cell_details[new_y][new_x].f == float('inf') or cell_details[new_y][new_x].f > f_new:
                        heapq.heappush(open_list, (f_new, g_new, new_y, new_x))
                        cell_details[new_y][new_x].f = f_new
                        cell_details[new_y][new_x].g = g_new
                        cell_details[new_y][new_x].h = h_new
                        cell_details[new_y][new_x].x = x
                        cell_details[new_y][new_x].y = y

    def trace_path(self, cell_details, goal):
        path = []
        x, y = goal

        while not (cell_details[y][x].x == x and cell_details[y][x].y == y):
            path.append((x, y))
            x, y = cell_details[y][x].x, cell_details[y][x].y

        path.append((x, y))
        path.reverse()
        return path


class AIService:
    def __init__(self):
        pass

    def get_direction(self,start,goal):
        return (pygame.Vector2(goal) - pygame.Vector2(start)).normalize() if start != goal else pygame.Vector2(0,0)


class PathService:
    def __init__(self, grid):
        self.a_star = AStar(grid)

    def get_path_from_pixels(self, start_px, goal_px):
        start = pixel_to_grid(start_px)
        goal = pixel_to_grid(goal_px)
        return self.a_star.get_path(start, goal)


class Robot:
    def __init__(self,pos):
        self.pos = pos
        self.size = GRID_SIZE//2,GRID_SIZE//2
        self.color = 'darkblue'

        self.vel = pygame.Vector2(0,0)
        self.rect = pygame.Rect(self.pos,self.size)

    def get_collidables_rects(self,collidibles):
        return [rect for rect in collidibles]

    def horizontal_collision(self,collider):
        if self.vel.x > 0:
            self.rect.right = collider.left
        if self.vel.x < 0:
            self.rect.left = collider.right

    def vertical_collision(self,collider):
        if self.vel.y > 0:
            self.rect.bottom = collider.top
        if self.vel.y < 0:
            self.rect.top = collider.bottom

    def update(self,dt,collidibles):
        self.rect.x += self.vel.x * dt * 100
        colidible_rects = self.get_collidables_rects(collidibles)
        collision_list = self.rect.collidelistall(colidible_rects)
        for c in collision_list:
            collided_object = collidibles[c]
            self.horizontal_collision(collided_object)

        self.rect.y += self.vel.y * dt * 100
        collision_list = self.rect.collidelistall(colidible_rects)
        for c in collision_list:
            collided_object = collidibles[c]
            self.vertical_collision(collided_object)

        self.vel = pygame.Vector2(0,0)

    def draw(self,screen):
        pygame.draw.rect(screen,self.color,self.rect)


class GeneratedMap:
    def __init__(self):
        self.drunkards = Drunkards()
        self.drunkards.walk()
        self.map = self.drunkards.game_map
        self.walls = []
        self.robot_pos = None
        self.get_walls()
        self.get_robot_pos()

    def get_walls(self):
        for row_index,row in enumerate(self.drunkards.game_map):
            for col_index,col in enumerate(row):
                if col == 0:
                    continue
                self.walls.append(pygame.Rect(col_index*GRID_SIZE,row_index*GRID_SIZE, GRID_SIZE,GRID_SIZE))

    def get_robot_pos(self):
        for row_index,row in enumerate(self.drunkards.game_map):
            for col_index,col in enumerate(row):
                if col == 0:
                    self.robot_pos = pygame.Rect(col_index*GRID_SIZE,row_index*GRID_SIZE,GRID_SIZE,GRID_SIZE).center
                    return 
                
    def draw(self,screen):
        for wall in self.walls:
            pygame.draw.rect(screen,"#242424",wall)
    

class World:
    def __init__(self):
        self.world_canvas = pygame.Surface((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.visible_area = pygame.Rect(0,0,100,100)
        self.generated_map = GeneratedMap()
        self.robot = Robot(self.generated_map.robot_pos)
        self.ai_service = AIService()
        self.path_service = PathService(self.generated_map.map)
        self.last_mouse_pos = None
        self.robot_waypoints = []
        self.walls = self.generated_map.walls

    def get_visible_area(self):
        self.visible_area.center = self.robot.rect.center
        self.visible_area.x = max(0, min(self.visible_area.x, 700))
        self.visible_area.y = max(0, min(self.visible_area.y, 500))

    def handle_inputs(self,inputs):
        pass

    def update(self,dt, mouse_pos):
        if self.last_mouse_pos is None or pygame.Vector2(mouse_pos).distance_to(self.last_mouse_pos) > 1:

            try:
                new_path = self.path_service.get_path_from_pixels(
                    self.robot.rect.center,
                    mouse_pos
                )
            except Exception:
                start = pixel_to_grid(self.robot.rect.center)
                goal = pixel_to_grid(mouse_pos)
                map_width = len(self.path_service.a_star.map[0])
                map_height = len(self.path_service.a_star.map)
                print(f"PATHFINDING ERROR: start={start}, goal={goal}, map_size=({map_width},{map_height})")
                traceback.print_exc()
                new_path = None

            if new_path:
                self.robot_waypoints = new_path 
                self.robot_waypoints.pop(0)
            self.last_mouse_pos = mouse_pos

        if self.robot_waypoints:
            first_waypoint = self.robot_waypoints[0]
            waypoint_center = grid_to_pixel_center(first_waypoint)

            self.robot.vel = self.ai_service.get_direction(self.robot.rect.center, waypoint_center)

            self.robot.update(dt, self.walls)

            if pygame.Vector2(self.robot.rect.center).distance_to(pygame.Vector2(waypoint_center)) <= 2:
                self.robot_waypoints.pop(0)
        else:
            self.robot.vel = pygame.Vector2(0,0)
        self.get_visible_area()

    def draw(self, screen):
        self.world_canvas.fill("#858585")

        if self.robot_waypoints:
            for w in self.robot_waypoints:
                pygame.draw.rect(self.world_canvas, 'red', 
                                pygame.Rect(w[0] * GRID_SIZE, w[1] * GRID_SIZE, GRID_SIZE, GRID_SIZE), 1)

        self.generated_map.draw(self.world_canvas)
        self.robot.draw(self.world_canvas)
        screen.blit(self.world_canvas.subsurface(self.visible_area),self.visible_area.topleft)


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.clock = pygame.Clock()
        self.world = World()

    def update(self,dt):
        self.world.update(dt,pygame.mouse.get_pos())

    def handle_inputs(self,inputs):
        if inputs[pygame.K_r]:
            self.world = World()
        self.world.handle_inputs(inputs)

    def draw(self):
        self.screen.fill('black')
        self.world.draw(self.screen)
        pygame.display.flip()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            inputs = pygame.key.get_just_pressed()
            dt = self.clock.tick(60) / 1000

            self.handle_inputs(inputs)
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)



if __name__ == "__main__":
    game = Game()
    asyncio.run(game.run())
    
