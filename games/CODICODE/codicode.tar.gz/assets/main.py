import pygame, os, sys, csv, asyncio
import copy
from dataclasses import dataclass
from enum import Enum, auto

TEST_GRID_WIDTH = 16
TEST_GRID_HEIGHT = 9
TILE_SIZE = 48 # Size of each grid square in pixels

class EntityType(Enum):
    OBJECT = auto()
    WORD = auto()

class ObjectType(Enum):
    CODI = auto()
    ROCK = auto()
    WALL = auto()
    FLAG = auto()

class WordType(Enum):
    NOUN = auto()
    CONJUCTIONS = auto()
    PROPERTY = auto()

class PropertyType(Enum):
    YOU = auto()
    PUSH = auto()
    STOP = auto()
    WIN = auto()

@dataclass
class WordDescription:
    type : WordType
    meaning: object

WORD_DICTIONARY = {
    'CODI' : WordDescription(type=WordType.NOUN,meaning=ObjectType.CODI),
    'ROCK' : WordDescription(type=WordType.NOUN,meaning=ObjectType.ROCK),
    'WALL' : WordDescription(type=WordType.NOUN,meaning=ObjectType.WALL),
    'FLAG' : WordDescription(type=WordType.NOUN,meaning=ObjectType.FLAG),
    'YOU' : WordDescription(type=WordType.PROPERTY,meaning=PropertyType.YOU),
    'PUSH' : WordDescription(type=WordType.PROPERTY,meaning=PropertyType.PUSH),
    'STOP' : WordDescription(type=WordType.PROPERTY,meaning=PropertyType.STOP),
    'WIN' : WordDescription(type=WordType.PROPERTY,meaning=PropertyType.WIN),
    'TEXT' : WordDescription(type=WordType.NOUN, meaning='TEXT'),
    'IS' : WordDescription(type=WordType.CONJUCTIONS,meaning=None)
}

@dataclass
class Rule:
    noun: ObjectType
    property: PropertyType

class Rules:
    def __init__(self):
        self.rules = []

    def get_rule_at(self,world,pos,axis):
        topleft_word = world.get_at(pos - axis)
        botright_word = world.get_at(pos + axis)

        topleft_word = [e for e in topleft_word if e.type == EntityType.WORD]
        botright_word = [e for e in botright_word if e.type == EntityType.WORD]

        if not topleft_word or not botright_word:
            return None

        topleft_description = WORD_DICTIONARY[topleft_word[0].id]
        botright_description = WORD_DICTIONARY[botright_word[0].id]

        if topleft_description.type == WordType.NOUN and botright_description.type == WordType.PROPERTY:
            return Rule(noun=topleft_description.meaning,property=botright_description.meaning)

    def check_horizontal_rules(self,world):
        for entity in world.entities:
            if entity.id != 'IS':
                continue

            rule = self.get_rule_at(world,entity.pos,pygame.Vector2(1,0))
            if rule:
                self.rules.append(rule)

    def check_vertical_rules(self,world):
        for entity in world.entities:
            if entity.id != 'IS':
                continue

            rule = self.get_rule_at(world,entity.pos,pygame.Vector2(0,1))
            if rule:
                self.rules.append(rule)

    def rebuild(self,world):
        world.properties = {}
        self.rules = []
        self.check_horizontal_rules(world)
        self.check_vertical_rules(world)

        for rule in self.rules:
            for e in world.entities:
                if e.type == EntityType.WORD:
                    world.properties.setdefault(e, set()).add(PropertyType.PUSH)

                # OBJECT rule: CODI IS YOU
                if e.type == EntityType.OBJECT and e.id == rule.noun:
                    world.properties.setdefault(e, set()).add(rule.property)

class Entity:
    def __init__(self,type,id,pos):
        self.type = type
        self.id = id
        self.pos = pos

OBJECT_GLYPHS = {
    ObjectType.CODI: 'CODI',
    ObjectType.ROCK: 'ROCK',
    ObjectType.WALL: 'WALL',
    ObjectType.FLAG: 'FLAG',
}

WORD_GLYPHS = {
    'CODI': 'CODI',
    'ROCK': 'ROCK',
    'WALL': 'WALL',
    'FLAG': 'FLAG',
    'YOU': 'YOU',
    'PUSH': 'PUSH',
    'STOP': 'STOP',
    'WIN': 'WIN',
    'IS': 'IS',
}

CHAR_TO_ENTITY = {
    'c' : (EntityType.OBJECT,ObjectType.CODI),
    'r' : (EntityType.OBJECT,ObjectType.ROCK),
    'w' : (EntityType.OBJECT,ObjectType.WALL),
    'f' : (EntityType.OBJECT,ObjectType.FLAG),

    'C' : (EntityType.WORD,'CODI'),
    'R' : (EntityType.WORD,'ROCK'),
    'L' : (EntityType.WORD,'WALL'),
    'F' : (EntityType.WORD,'FLAG'),
    'Y' : (EntityType.WORD,'YOU'),
    'P' : (EntityType.WORD,'PUSH'),
    'S' : (EntityType.WORD,'STOP'),
    'N' : (EntityType.WORD,'WIN'),
    'I' : (EntityType.WORD,'IS')
}

LEVEL_ONE_PATH = os.path.join('assets','levels','level_one.csv')

class World:
    def __init__(self):
        self.entities = []
        self.properties = {} 
        self.history = []
        self.load_level()

    def load_level(self):
        # Fallback if the CSV file doesn't exist yet so you can test it immediately
        if not os.path.exists(LEVEL_ONE_PATH):
            print(f"Warning: {LEVEL_ONE_PATH} not found. Loading fallback level.")
            level = [
                "w w w w w w w w w w w w w w w w".split(),
                "w . . . . . . . . . . . . . . w".split(),
                "w . C I Y . . . . . . . F . . w".split(),
                "w . . . . . r . . . . . I . . w".split(),
                "w . . c . . r . . . . . N . . w".split(),
                "w . . . . . R I P . . . . f . w".split(),
                "w . . . . . . . . . . . . . . w".split(),
                "w . . . . . . . . . . . . . . w".split(),
                "w w w w w w w w w w w w w w w w".split(),
            ]
        else:
            with open(LEVEL_ONE_PATH) as f:
                level = list(csv.reader(f))
                
        for y,row in enumerate(level):
            for x,cell in enumerate(row):
                if cell == '.':
                    continue
                if cell in CHAR_TO_ENTITY:
                    etype, eid = CHAR_TO_ENTITY[cell]
                    self.entities.append(Entity(etype,eid,pygame.Vector2(x,y)))

    def has_property(self, entity, prop):
        return prop in self.properties.get(entity, set())
    
    def movers(self):
        return [
            e for e in self.entities if e.type == EntityType.OBJECT
            and self.has_property(e,PropertyType.YOU)
        ]
    
    def stoppers(self):
        return [
            e for e in self.entities if self.has_property(e,PropertyType.STOP)
        ]
    
    def pushers(self):
        return [
            e for e in self.entities
            if self.has_property(e, PropertyType.PUSH)
        ]
    
    def winners(self):
        return [
            e for e in self.entities if e.type == EntityType.OBJECT
            and self.has_property(e,PropertyType.WIN)
        ]

    def get_at(self,pos):
        entity_list = []
        for e in self.entities:
            if e.pos == pos:
                entity_list.append(e)
        return entity_list

    def check_win(self):
        for m in self.movers():
            for w in self.winners():
                if m.pos == w.pos:
                    return True
        return False

    def is_bound(self,pos):
        return(0 <= pos.x < TEST_GRID_WIDTH and
        0 <= pos.y < TEST_GRID_HEIGHT)

    def can_move(self,entity,direction):
        target = entity.pos + direction
        occupants = self.get_at(target)

        if not self.is_bound(target):
            return False

        for o in occupants:
            if o in self.stoppers():
                return False
            
            if o in self.pushers():
                if not self.can_move(o,direction):
                    return False

        return True
        
    def do_move(self,entity,direction):
        target = entity.pos + direction
        occupants = self.get_at(target)

        for o in occupants:
            if o in self.pushers():
                self.do_move(o,direction)

        entity.pos += direction

    def move(self,direction):
        self.history.append(copy.deepcopy(self.entities))
        for e in self.movers():
            if self.can_move(e,direction):
                self.do_move(e,direction)

    def undo(self):
        if self.history:
            self.entities = self.history.pop()

                
class Main:
    def __init__(self):
        pygame.init()
        # Initialize the display window
        self.screen = pygame.display.set_mode((TEST_GRID_WIDTH * TILE_SIZE, TEST_GRID_HEIGHT * TILE_SIZE))
        pygame.display.set_caption("Codi Is You")
        
        # Initialize a font for drawing letters
        pygame.font.init()
        self.font = pygame.font.SysFont('Arial', 14, bold=True)
        self.big_font = pygame.font.SysFont('Arial', 48, bold=True)
        
        self.world = World()
        self.rules = Rules()
        self.has_won = False

    def update(self):
        pass

    def draw(self):
        # 1. Clear the screen with a dark gray background
        self.screen.fill((30, 30, 30))

        # 2. Draw all entities
        for entity in self.world.entities:
            x = int(entity.pos.x) * TILE_SIZE
            y = int(entity.pos.y) * TILE_SIZE
            rect = pygame.Rect(x, y, TILE_SIZE, TILE_SIZE)

            # Assign colors based on entity type for visual flair
            bg_color = (0, 0, 0)
            text_color = (255, 255, 255)
            text_str = ""

            if entity.type == EntityType.OBJECT:
                text_str = OBJECT_GLYPHS[entity.id]
                # Specific colors for objects
                if entity.id == ObjectType.CODI: bg_color = (220, 80, 80)
                elif entity.id == ObjectType.ROCK: bg_color = (139, 69, 19)
                elif entity.id == ObjectType.WALL: bg_color = (100, 100, 100)
                elif entity.id == ObjectType.FLAG: bg_color = (255, 215, 0)
            
            elif entity.type == EntityType.WORD:
                text_str = WORD_GLYPHS[entity.id]
                bg_color = (40, 40, 40) # Dark block for words
                text_color = (180, 180, 255) # Light blueish text for words

            # Draw the colored block and a border
            pygame.draw.rect(self.screen, bg_color, rect)
            pygame.draw.rect(self.screen, (10, 10, 10), rect, 2)

            # Draw the text centered in the block
            text_surface = self.font.render(text_str, True, text_color)
            text_rect = text_surface.get_rect(center=rect.center)
            self.screen.blit(text_surface, text_rect)

        # 3. Draw a win message if the game is won
        if self.has_won:
            win_surface = self.big_font.render("YOU WIN!", True, (0, 255, 0))
            # Outline/shadow for readability
            shadow_surface = self.big_font.render("YOU WIN!", True, (0, 0, 0))
            center_x, center_y = (TEST_GRID_WIDTH * TILE_SIZE) // 2, (TEST_GRID_HEIGHT * TILE_SIZE) // 2
            
            self.screen.blit(shadow_surface, shadow_surface.get_rect(center=(center_x + 3, center_y + 3)))
            self.screen.blit(win_surface, win_surface.get_rect(center=(center_x, center_y)))

    async def run(self):
        clock = pygame.time.Clock()
        self.rules.rebuild(self.world) # Initial rule setup

        while True:
            direction = None
            undo_pressed = False

            # --- EVENT HANDLING ---
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                
                if event.type == pygame.KEYDOWN and not self.has_won:
                    if event.key in (pygame.K_w, pygame.K_UP):
                        direction = pygame.Vector2(0, -1)
                    elif event.key in (pygame.K_s, pygame.K_DOWN):
                        direction = pygame.Vector2(0, 1)
                    elif event.key in (pygame.K_a, pygame.K_LEFT):
                        direction = pygame.Vector2(-1, 0)
                    elif event.key in (pygame.K_d, pygame.K_RIGHT):
                        direction = pygame.Vector2(1, 0)
                    elif event.key == pygame.K_z:
                        undo_pressed = True

            # --- LOGIC UPDATES ---
            if undo_pressed:
                self.world.undo()
                self.rules.rebuild(self.world)
                
            elif direction:
                self.world.move(direction)
                self.rules.rebuild(self.world)
                
                # Check win condition after moving
                if self.world.check_win():
                    self.has_won = True

            # --- DRAWING ---
            self.draw()
            pygame.display.flip() # Update the full display Surface to the screen
            clock.tick(30) # Cap framerate at 30 FPS
            await asyncio.sleep(0)

if __name__ == "__main__":
    main = Main()
    asyncio.run(main.run())