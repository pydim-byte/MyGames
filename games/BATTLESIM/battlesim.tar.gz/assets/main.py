import pygame,os,sys, asyncio
import numpy as np
from enum import Enum,auto
     
     
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
GRID_CELL_SIZE = 20
FPS = 60


'''


Characters are rects 20x20 pixels that in it have 16 smaller  rexts 5x5 pixels

Bellow are pixel and relative position in the x,y cordinates 

_____________________________________
|x0 y0   |x5 y0   |x10 y0  |x15 y0  |
|________|________|________|________|
|x0 y5   |x5 y5   |x10 y5  |x15 y5  |
|________|________|________|________|
|x0 y10  |x5 y10  |x10 y10 |x15 y10 |
|________|________|________|________|
|x0 y15  |x5 y15  |x10 y15 |x15 y15 |
|________|________|________|________|

_____________________________________
|0x 0y   |1x 0y   |2x 0y   |3x 0y   |
|________|________|________|________|
|0x 1y   |1x 1y   |2x 1y   |3x 1y   |
|________|________|________|________|
|0x 2y   |1x 2y   |2x 2y   |3x 2y   |
|________|________|________|________|
|0x 3y   |1x 3y   |2x 3y   |3x 3y   |
|________|________|________|________|


'''



class ObjectDirection(Enum):
    LEFT = auto()
    RIGHT = auto()


class BaseTroop:
    def __init__(self,pos_x=0,pos_y=0,facing=ObjectDirection.LEFT,team_color='darkgreen'):
        self.hp = 20
        self.alive = True
        self.can_receive_damage = True
        self.can_deal_damage = False

        self.pixel_size = 5
        self.body_size = GRID_CELL_SIZE
        self.grid_position_x = pos_x
        self.grid_position_y = pos_y

        self.facing = facing

        self.team_color = team_color
        self.body_color = self.team_color

        self.color_map = {
            1 : "grey",
            2 : "gold"
        }


        self.pixel_position = pygame.Vector2(0*self.pixel_size + self.body_size*self.grid_position_x,
                                             0*self.pixel_size + self.body_size*self.grid_position_y)

        self.movement_vector = pygame.Vector2(0,0)
        self.knockback = pygame.Vector2(0,0)
        self.knocked = False
        self.knockback_timer = 0
        self.knockback_durarion = 0.25

        self.body_rect = pygame.Rect(self.pixel_position,(self.body_size,self.body_size))
        
        self.weapon_coordinates = np.array([
            [0, 0, 0, 2],
            [1, 0, 2, 0],
            [0, 1, 0, 0],
            [1, 0, 1, 0],
        ])

        if self.facing == ObjectDirection.RIGHT:
            self.flip()

    def flip(self):
        self.weapon_coordinates = np.fliplr(self.weapon_coordinates)


    def update_facing(self):
        old_facing = self.facing
        if self.movement_vector.x < 0:
            self.facing = ObjectDirection.RIGHT
        if self.movement_vector.x > 0:
            self.facing = ObjectDirection.LEFT
        if old_facing != self.facing:
            self.flip()

    def move(self,direction):
        self.movement_vector = direction

    def get_knocked(self,direction):
        self.knockback_timer = 0
        self.knocked = True
        self.knockback = direction

    def take_damage(self,amount=1):
        self.hp -= amount
        if self.hp <= 0:
            self.alive = False

    def on_hit(self, direction):
        self.get_knocked(direction)
        self.take_damage()

    def check_death(self):
        if self.hp <= 0:
            self.alive = False

    def update(self,dt):
        self.update_facing()
        if not self.knocked:
            self.pixel_position += self.movement_vector * dt * 100
        else:
            self.knockback_timer += dt
            if self.knockback_timer < self.knockback_durarion:
                self.pixel_position += self.knockback * dt * 200
            else:
                self.knocked = False
                self.knockback_timer = 0

        self.body_rect.topleft = self.pixel_position
        self.body_rect.clamp_ip(pygame.Rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT))
        self.movement_vector = pygame.Vector2(0,0)
        self.check_death()

    def draw(self,screen):
        # BODY
        pygame.draw.rect(screen,self.body_color,self.body_rect)

        # WEAPON
        for y in range(self.weapon_coordinates.shape[0]):
            for x in range(self.weapon_coordinates.shape[1]):
                value = self.weapon_coordinates[y,x]
                if not self.weapon_coordinates[y,x]:
                    continue
                color = self.color_map[value]
                pygame.draw.rect(screen,color,
                                (self.body_rect.x + x*self.pixel_size,
                                self.body_rect.y + y*self.pixel_size,
                                self.pixel_size,self.pixel_size))


class Warior(BaseTroop):
    def __init__(self, pos_x=0, pos_y=0, facing=ObjectDirection.LEFT, team_color='darkgreen'):
        super().__init__(pos_x, pos_y, facing, team_color)
        self.can_receive_damage = True
        self.can_deal_damage = True

class Archer(BaseTroop):
    def __init__(self, pos_x=0, pos_y=0, facing=ObjectDirection.LEFT, team_color='darkgreen'):
        super().__init__(pos_x, pos_y, facing, team_color)
        self.hp = 10 
        self.projectiles = []

        self.attack_range = 300
        self.attack_timer = 0 
        self.attack_cooldown = 1
        self.attacked = False
        self.attack_direction = pygame.Vector2(0,0)

        self.color_map = {
            1 : "gold",
            2 : "grey"
        }

        self.weapon_coordinates = np.array([
            [0, 0, 1, 0],
            [0, 2, 0, 1],
            [0, 2, 0, 1],
            [0, 0, 1, 0],
        ])

        if self.facing == ObjectDirection.RIGHT:
            self.flip()

    def update_attack_timer(self,dt):
        if self.attacked:
            if self.attack_timer < self.attack_cooldown:
                self.attack_timer += dt
                return
            self.attack_timer = 0
            self.attacked = False

    def attack(self, direction):
        if not self.attacked:
            self.attacked = True
            self.attack_direction = direction
            self.projectiles.append(Arrow(self.body_rect.center,self.attack_direction,self.team_color))

    def update_facing(self):
        old_facing = self.facing
        if not self.attacked:
            if self.movement_vector.x < 0:
                self.facing = ObjectDirection.RIGHT
            if self.movement_vector.x > 0:
                self.facing = ObjectDirection.LEFT
        else:
            if self.attack_direction.x < 0:
                self.facing = ObjectDirection.RIGHT
            if self.attack_direction.x > 0:
                self.facing = ObjectDirection.LEFT
        if old_facing != self.facing:
            self.flip()


    def update(self, dt):
        self.update_attack_timer(dt)
        return super().update(dt)


class Arrow:
    def __init__(self,pos,direction,team_color='darkgreen'):
        self.team_color = team_color
        self.can_receive_damage = False
        self.can_deal_damage = True
        self.should_despawn  = False
        self.pos = pos
        self.direction = direction
        self.body_rect = pygame.Rect(pos,(5,5))

    def move(self,dt):
        self.pos += self.direction * dt * 200
        self.body_rect.topleft = self.pos

    def update(self,dt):
        self.move(dt)

    def draw(self,screen):
        pygame.draw.rect(screen,'white',self.body_rect)


class TroopRegistry:
    def __init__(self):
        self.troops = []

    def add_troop(self,troop):
        self.troops.append(troop)

    def remove_troop(self,troop):
        self.troops.remove(troop)


class TroopFactory:
    def __init__(self,registry):
        self.registry = registry

    def spawn_troop(self,troop,pos_x,pos_y,facing,team_color):
        self.registry.add_troop(troop(pos_x,pos_y,facing,team_color))


class BattleManager:
    def __init__(self):
        self.troop_registry = TroopRegistry()
        self.projectile_registry = []
        self.colidible = []
        self.troop_factory = TroopFactory(self.troop_registry)
        self.ai_service = AIService()
        self.collision_service = CollisionService()

    def update(self,dt):
        for troop in self.troop_registry.troops:
            self.ai_service.get_direction_to_nearest_enemy(troop,self.troop_registry.troops)

            if hasattr(troop, "projectiles") and troop.projectiles:
                self.projectile_registry.append(troop.projectiles.pop())

            self.colidible = [t for t in self.troop_registry.troops]
            if self.projectile_registry:
                self.colidible.extend([p for p in self.projectile_registry])

            self.collision_service.get_collisions(troop,self.colidible)
            troop.update(dt)

        for p in self.projectile_registry:
            p.update(dt)

        self.troop_registry.troops = [troop for troop in self.troop_registry.troops if troop.alive]
        self.projectile_registry = [p for p in self.projectile_registry if not p.should_despawn]


    def draw(self,screen):
        for troop in self.troop_registry.troops:
            troop.draw(screen)

        for p in self.projectile_registry:
            p.draw(screen)

  
class AIService:
    def __init__(self):
        pass

    def get_direction_to_nearest_enemy(self,troop,registry):
        distance_to_nearest_enemy = None
        direction_to_nearest_enemy = pygame.Vector2(0,0)

        for enemy in registry:
            if enemy.team_color == troop.team_color:
                continue
            troop_pos = pygame.Vector2(troop.body_rect.center)
            enemy_pos = pygame.Vector2(enemy.body_rect.center)
            distance_to_enemy = troop_pos.distance_to(enemy_pos)
            if distance_to_nearest_enemy is None:
                distance_to_nearest_enemy = distance_to_enemy
                direction_to_nearest_enemy = (enemy_pos - troop_pos).normalize() if enemy_pos != troop_pos else pygame.Vector2(0,0)
                continue
            if distance_to_enemy < distance_to_nearest_enemy:
                distance_to_nearest_enemy = distance_to_enemy
                direction_to_nearest_enemy = (enemy_pos - troop_pos).normalize() if enemy_pos != troop_pos else pygame.Vector2(0,0)

        if hasattr(troop, "attack") and troop.attack_range >= distance_to_nearest_enemy:
            troop.attack(direction_to_nearest_enemy)
        else:
            troop.move(direction_to_nearest_enemy)


class CollisionService:
    def __init__(self):
        pass

    def get_collisions(self,troop,registry):
        for enemy in registry:
            if enemy.team_color == troop.team_color:
                continue
            if troop.body_rect.colliderect(enemy.body_rect):
                self.get_collision_resolution(troop,enemy)

    def get_collision_resolution(self, a, b):
        if a.can_deal_damage and b.can_receive_damage:
            b.on_hit((pygame.Vector2(b.body_rect.center) - pygame.Vector2(a.body_rect.center)).normalize())
        elif b.can_deal_damage and a.can_receive_damage:
            a.on_hit((pygame.Vector2(a.body_rect.center) - pygame.Vector2(b.body_rect.center)).normalize())

        if isinstance(a, Arrow) and isinstance(b, BaseTroop):
            a.should_despawn = True

        elif isinstance(b, Arrow) and isinstance(a, BaseTroop):
            b.should_despawn = True


class GameMode(Enum):
    EDITOR = auto()
    SIMULATION = auto()


class Game:
    def __init__(self):
        pygame.init()
        self.screen =pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.screen_color = (20,20,20)
        self.clock = pygame.time.Clock()
        self.battle_manager = BattleManager()
        self.mode = GameMode.EDITOR
        self.current_troop = Warior
        self.current_team = 'darkgreen'

    def handle_editor_input(self):
        buttons = pygame.key.get_pressed()
        key = pygame.key.get_pressed()
        mouse_x, mouse_y = pygame.mouse.get_pos()
        grid_x = mouse_x // GRID_CELL_SIZE
        grid_y = mouse_y // GRID_CELL_SIZE

        if key[pygame.K_1]:
            self.current_troop = Warior
        if key[pygame.K_2]:
            self.current_troop = Archer

        if buttons[pygame.K_q]:
            self.current_team = 'darkred'

        if buttons[pygame.K_e]:
            self.current_team = 'darkgreen'

        if buttons[pygame.K_w]:
            for troop in self.battle_manager.troop_registry.troops:
                if troop.grid_position_x == grid_x and troop.grid_position_y == grid_y:
                    self.battle_manager.troop_registry.remove_troop(troop)
                    break
            facing = ObjectDirection.LEFT if grid_x < (SCREEN_WIDTH // 2 // GRID_CELL_SIZE) else ObjectDirection.RIGHT
            self.battle_manager.troop_factory.spawn_troop(self.current_troop,grid_x, grid_y, facing, self.current_team)

    def draw_grid_highlight(self):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        grid_x = (mouse_x // GRID_CELL_SIZE) * GRID_CELL_SIZE
        grid_y = (mouse_y // GRID_CELL_SIZE) * GRID_CELL_SIZE
        pygame.draw.rect(self.screen, pygame.Color(self.current_team), 
                        (grid_x, grid_y, GRID_CELL_SIZE, GRID_CELL_SIZE), 2)

    def handle_inputs(self,inputs):
        if inputs[pygame.K_SPACE]:
            self.mode = GameMode.SIMULATION
        
    def update(self,dt):
        if self.mode == GameMode.EDITOR:
            self.handle_editor_input()
        elif self.mode == GameMode.SIMULATION:
            self.battle_manager.update(dt)
        
    def draw(self):
        self.screen.fill(self.screen_color)
        if self.mode == GameMode.EDITOR:
            self.draw_grid_highlight()
        self.battle_manager.draw(self.screen)
        pygame.display.flip()
        
    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            
            inputs = pygame.key.get_pressed()         
            dt = self.clock.tick(FPS) / 1000 

            self.handle_inputs(inputs)
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)
            
game = Game()
asyncio.run(game.run())