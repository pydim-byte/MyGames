import json

with open('theme.json') as f:
    test = json.load(f)


print(test["selection_list"])