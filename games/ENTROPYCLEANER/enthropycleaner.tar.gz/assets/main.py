# /// script
# dependencies = [
#   "pygame_gui",
#   "python-i18n",
# ]
# ///
"""
FRAME FLOW (IMPORTANT):

Game.run
 ├─ handle_inputs()
 ├─ Cosmos.update()
 │    ├─ SpotSpawner.update()
 │    ├─ SpotRegistry.update()
 │    └─ Cosmos.build_data()
 ├─ UISystem.update()
 └─ draw()

UI reads ONLY from DataSystem.
Gameplay never reads from UI.
"""


import pygame, sys, os,json, random, colorsys, asyncio
import pygame_gui
from enum import Enum, auto


SCREEN_WIDTH, SCREEN_HEIGHT = 960, 540
FPS = 30


class SpotState(Enum):
    SHRINKING = auto()
    GROWNING = auto()
    DEAD = auto()


class SpotType(Enum):
    NORMAL = auto()
    VIBRANT = auto()
    EXPLOSIVE = auto()
    VAMPIRE = auto()


class ShiftColors:
    def __init__(self):
        pass

    def __call__(self,spot,dt):
        r,g,b = spot.color
        h,s,v = colorsys.rgb_to_hsv(r,g,b)
        h = (h + dt * spot.CONSTANTS["COLOR_SPEED"]) % 1.0
        r,g,b = colorsys.hsv_to_rgb(h, 1, 1)
        spot.color = (int(r*255), int(g*255), int(b*255))


class ExplodeOnDeath:
    def __init__(self):
        self.done = False

    def __call__(self,spot,dt):
        if spot.state == SpotState.DEAD and not self.done:
            self.done = True
            spot.on_death(spot)


class LeachSize:
    def __init__(self,spots):
        self.spots = spots

    def __call__(self,spot,dt):
        collided_rects = spot.rect.collidelistall([s.rect for s in self.spots])
        if not collided_rects:
            return
        collided_spots = [self.spots[i] for i in collided_rects if self.spots[i] != spot]
        leach_targets = len(collided_rects)
        if spot.size < 200:
            for s in collided_spots:
                if s.size > 60:
                    s.start_to_shrink()

            spot.growth = min(280,spot.CONSTANTS["GROWTH"] * leach_targets)


class EntropySpot:
    """
    Class for main object in the game

    x,y,size,color -> parameters for collision Rect and to draw circle on screen

    constants,behaviour,spot_type -> describe base stats for a spot_type

    on_death -> object that will be called on Spot death

    layer -> z-position for the spot
    """
    def __init__(self,x,y,size,color,constants,behaviour,spot_type,on_death=None,layer=0):
        self.pos = pygame.Vector2(x,y)
        self.size = size
        self.color = color
        self.CONSTANTS = constants
        self.layer = layer
        self.behaviour = behaviour
        self.type = spot_type
        self.on_death = on_death
        self.shrink_time = 0
        self.state = SpotState.GROWNING
        self.rect = pygame.Rect(self.pos.x,self.pos.y,self.size,self.size)
        self.load_constants()

    def load_constants(self):
        self.growth = self.CONSTANTS["GROWTH"]
        self.shrink = self.CONSTANTS["SHRINK"]
        self.shrink_duration = self.CONSTANTS["SHRINK_DURATION"]
        self.death_width = self.CONSTANTS["DEATH_WIDTH"]

    def start_to_shrink(self):
        self.shrink_time = 0
        self.state = SpotState.SHRINKING

    def decide_scale_direction(self,dt):
        if self.state == SpotState.GROWNING:
            return
        if self.state == SpotState.SHRINKING:
            self.shrink_time += dt
            if self.shrink_time < self.shrink_duration:
                return
            else:
                self.state = SpotState.GROWNING
                self.shrink_time = 0

    def check_death(self):
        if self.rect.width < self.death_width:
            self.state = SpotState.DEAD

    def update(self,dt):
        self.decide_scale_direction(dt)

        if self.state == SpotState.GROWNING:
            self.rect.inflate_ip(self.growth * dt, self.growth * dt)
        elif self.state == SpotState.SHRINKING:
            self.rect.inflate_ip(self.shrink * dt, self.shrink * dt)

        self.check_death()

        if self.behaviour:
            for b in self.behaviour:
                b(self,dt)
                        
        
        
    def draw(self,screen):
        pygame.draw.circle(screen,self.color,self.rect.center,self.rect.width//2)


class SpotRegistry:
    """
    Class that stores all the Spots in the game

    del_dead removes dead spots from self.spots
    """
    def __init__(self):
        self.spots = []

    def add_spot(self,spot):
        self.spots.append(spot)

    def del_dead(self):
        self.spots = [spot for spot in self.spots if spot.state != SpotState.DEAD]

    def get_top_object(self, rect):
        collision = rect.collidelistall([s.rect for s in self.spots])
        if not collision:
            return None
        return max((self.spots[i] for i in collision), key=lambda s: s.layer)

    def update(self,dt):
        for spot in self.spots:
            spot.update(dt)
        self.del_dead()
        

    def draw(self,screen):
        for spot in self.spots:
            spot.draw(screen)


class SpotFactory:
    """
    Class that gives stats for newly created spots and adds them to the registry

    registry -> SpotRegistry
    constants -> constant stats for each spot_type
    bounds -> bound random value withinh min and max value
    """
    def __init__(self,registry,constants,bounds):
        self.registry = registry
        self.spot_constants = constants
        self.min_x, self.max_x, self.min_y, self.max_y, self.min_rgb, self.max_rgb  = bounds

    def create_spot(self,pos,size,layer,spot_type,on_death=None):
        color = (random.randint(self.min_rgb,self.max_rgb), 
                 random.randint(self.min_rgb,self.max_rgb), 
                 random.randint(self.min_rgb,self.max_rgb)) 

        behaviour = []

        if spot_type == SpotType.VIBRANT:
            behaviour.append(ShiftColors())

        if spot_type == SpotType.EXPLOSIVE:
            behaviour.append(ExplodeOnDeath())

        if spot_type == SpotType.VAMPIRE:
            behaviour.append(LeachSize(self.registry.spots))

        return EntropySpot(pos[0],pos[1],
                           size,color,
                           self.spot_constants[spot_type.name],behaviour,
                           spot_type,on_death,layer)


class SpotSpawner:
    """
    Class that ask for cration of certian spot from SpotFactory

    spawn_cooldown -> how offted spots gets created
    registry -> SpotRegistry
    factory -> SpotFactory
    bounds -> bounds (min and max) for the random stats Spot can get
    on_death -> function that is called by Spot on death
    """
    def __init__(self,spawn_cooldown, registry, factory, bounds, on_death):
        self.spot_making_time = 0
        self.spawn_cooldown = spawn_cooldown
        self.registry = registry
        self.factory = factory
        self.bounds = bounds
        self.on_death = on_death
        self.min_x, self.max_x, self.min_y, self.max_y, self.min_size, self.max_size  = bounds

    def spawn_spot(self):
        pos_x = random.randint(self.min_x,self.max_x)
        pos_y = random.randint(self.min_y,self.max_y)
        size = random.randint(self.min_size,self.max_size)

        top_obj = self.registry.get_top_object(pygame.Rect(pos_x,pos_y,size,size)) 
        layer = top_obj.layer + 1 if top_obj else 0

        spot_type = random.choice([SpotType.NORMAL,SpotType.VIBRANT,SpotType.EXPLOSIVE,SpotType.VAMPIRE])

        on_death = None

        if spot_type == SpotType.EXPLOSIVE:
            on_death = self.on_death

        spot = self.factory.create_spot((pos_x,pos_y),
                                      size,layer,spot_type,on_death)
        
        self.registry.add_spot(spot)

    def update(self,dt):
        self.spot_making_time += dt
        if self.spot_making_time >= self.spawn_cooldown:
            self.spawn_spot()
            self.spot_making_time = 0


class ExplosionSystem:
    """
    Class that handles on_death behaviour of Explosive Spots

    handle_explosion creates multiple spots in place of one that exploded

    registry -> SpotRegistry
    factory -> SpotFactory
    bounds -> bounds (min and max) for the random stats Spot can get
    """
    def __init__(self, registry, factory, bounds):
        self.registry = registry
        self.factory = factory
        self.min_x, self.max_x, self.min_y, self.max_y = bounds

    def handle_explosion(self, spot):
        explosion_offset_min_x = min(self.max_x,
                                 max(self.min_x,
                                    spot.rect.x - spot.CONSTANTS["EXPLOSIVE_RADIUS"]))
        explosion_offset_max_x = min(self.max_x,
                                 max(self.min_x,
                                    spot.rect.x + spot.CONSTANTS["EXPLOSIVE_RADIUS"]))
        explosion_offset_min_y = min(self.max_y,
                                 max(self.min_y,
                                    spot.rect.y - spot.CONSTANTS["EXPLOSIVE_RADIUS"]))
        explosion_offset_max_y = min(self.max_y,
                                 max(self.min_y,
                                    spot.rect.y + spot.CONSTANTS["EXPLOSIVE_RADIUS"]))
        
        for _ in range(spot.CONSTANTS["EXPLOSIONS_COUNT"]):
            pos_x = random.randint(explosion_offset_min_x,explosion_offset_max_x)
            pos_y = random.randint(explosion_offset_min_y,explosion_offset_max_y)
            size = random.randint(spot.CONSTANTS["EXPLOSION_SIZE_MIN"],spot.CONSTANTS["EXPLOSION_SIZE_MAX"])

            top_obj = self.registry.get_top_object(pygame.Rect(pos_x,pos_y,size,size))
            layer = top_obj.layer + 1 if top_obj else 0

            new_spot_type = random.choice([SpotType.NORMAL,SpotType.VIBRANT])

            new_spot = self.factory.create_spot((pos_x,pos_y),
                                                size,layer,new_spot_type)
                    
            self.registry.add_spot(new_spot)


class InteractionSystem:
    """
    Class used for managing inputs between Game and Cosmos

    shrink_at_point call shrink function of the top EntropySpot that collided with mouse, reperesented by pos
    """
    def __init__(self, registry):
        self.registry = registry

    def shrink_at_point(self, pos, size=1):
        top_obj = self.registry.get_top_object(pygame.Rect(pos[0], pos[1], size, size))
        if top_obj:
            top_obj.start_to_shrink()


class Cosmos:
    """
    Class for managing EntropySpots creation
    __init__ load all the systems for EntropySpot creation

    build_data colects info from all EntorpySpots in the game, for later use by UI

    update handle updates all the EntorpySpots in the registry and updated registry and data system with new data
    """
    def __init__(self):
        self.load_constants()
        self.spot_registry = SpotRegistry()

        self.interaction_system = InteractionSystem(self.spot_registry)

        self.spot_factory = SpotFactory(self.spot_registry,self.spot_costants, 
                                        (self.spot_min_x, self.spot_max_x, 
                                         self.spot_min_y, self.spot_max_y, 
                                         self.spot_min_rgb, self.spot_max_rgb))
        
        self.explosion_system = ExplosionSystem(self.spot_registry,self.spot_factory,
                                                (self.spot_min_x, self.spot_max_x, 
                                                self.spot_min_y, self.spot_max_y))
        
        self.spot_spawner = SpotSpawner(self.spot_making_cooldown,
                                        self.spot_registry,self.spot_factory,
                                        (self.spot_min_x, self.spot_max_x, 
                                         self.spot_min_y, self.spot_max_y, 
                                         self.spot_min_size, self.spot_max_size),
                                         self.explosion_system.handle_explosion)
        
        self.data = DataSystem()

    def load_constants(self):
        self.costants_path = os.path.join('cosmos_constants.json')
        self.spot_costants_path = os.path.join('spot_constants.json')
        with open(self.costants_path) as f:
            self.CONSTANTS = json.load(f)
        self.spot_making_cooldown = self.CONSTANTS["SPOT_MAKING_COOLDOWN"]
        self.spot_min_x = self.CONSTANTS["SPOT_MIN_X"]
        self.spot_max_x = self.CONSTANTS["SPOT_MAX_X"]
        self.spot_min_y = self.CONSTANTS["SPOT_MIN_Y"]
        self.spot_max_y = self.CONSTANTS["SPOT_MAX_Y"]
        self.spot_min_size = self.CONSTANTS["SPOT_MIN_SIZE"]
        self.spot_max_size = self.CONSTANTS["SPOT_MAX_SIZE"]
        self.spot_min_rgb = self.CONSTANTS["SPOT_MIN_RGB"]
        self.spot_max_rgb = self.CONSTANTS["SPOT_MAX_RGB"]

        with open(self.spot_costants_path) as f:
            self.spot_costants = json.load(f)

    def build_data(self):
        if self.spot_registry.spots:
            spot_data = self.spot_registry.spots
            self.data.spot_count = len(spot_data)
            self.data.top_layer = max(spot_data, key=lambda s:s.layer).layer
            self.data.normal_spots_count = len([s for s in spot_data if s.type == SpotType.NORMAL])
            self.data.vibrant_spots_count = len([s for s in spot_data if s.type == SpotType.VIBRANT])
            self.data.explosive_spots_count = len([s for s in spot_data if s.type == SpotType.EXPLOSIVE])
            self.data.vampire_spots_count = len([s for s in spot_data if s.type == SpotType.VAMPIRE])
        else:
            self.data.spot_count = 0
            self.data.top_layer = 0
            self.data.normal_spots_count = 0
            self.data.vibrant_spots_count = 0
            self.data.explosive_spots_count = 0
            self.data.vampire_spots_count = 0

    def handle_inputs(self,inputs):
        pass

    def update(self,dt):
        self.spot_spawner.update(dt)
        self.spot_registry.update(dt)
        self.build_data()


    def draw(self,screen):
        self.spot_registry.draw(screen)


class DataSystem:
    """
    Class that holds the data for UI to use

    Rebuilt every frame by Cosmos.
    Contains NO references to entities.
    UI must treat this as read-only.
    """
    def __init__(self):
        self.spot_count = 0
        self.top_layer = 0
        self.normal_spots_count = 0
        self.vibrant_spots_count = 0
        self.explosive_spots_count = 0
        self.vampire_spots_count = 0


class UISystem:
    """
    Class for the game UI thought pygame_gui module

    data -> DataSystem
    inspector -> Cosmos.spot_registry

    IMPORTANT RULES:
    - UI must never mutate gameplay state
    - UI may inspect SpotRegistry ONLY for hover/inspection
    - All counters and stats come from DataSystem
    """
    def __init__(self,data,inspector):
        self.data = data
        self.inspector = inspector

        self.ui_manager = pygame_gui.UIManager((SCREEN_WIDTH,SCREEN_HEIGHT),theme_path='theme.json')
        self.ui_sidebar = pygame_gui.elements.UISelectionList(relative_rect=pygame.Rect(760,0,
                                                              200,540),
                                                              item_list=['pause','resume','forward'],
                                                              manager=self.ui_manager)
        
        self.spot_counter = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,162,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.max_layer_indicator = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,216,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.normal_spots_count = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,270,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.vibrant_spots_count = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,324,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.explosive_spots_count = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,378,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.vampire_spots_count = pygame_gui.elements.UILabel(relative_rect=pygame.Rect(760,432,
                                                        200,54),
                                                        text='0',
                                                        manager=self.ui_manager)
        
        self.spot_atribute_display = pygame_gui.elements.UITextBox(relative_rect=pygame.Rect(0,0,
                                                                    240,240),
                                                                    html_text='',
                                                                    visible=False,
                                                                    manager=self.ui_manager)
        
    def rebuild_ui(self):
        self.spot_counter.text = f'ENTROPY COUNT:{self.data.spot_count}'
        self.spot_counter.rebuild()

        top_layer = self.data.top_layer
        normal_spots_count = self.data.normal_spots_count
        vibrant_spots_count = self.data.vibrant_spots_count
        explosive_spots_count = self.data.explosive_spots_count
        vampire_spots_count = self.data.vampire_spots_count


        self.max_layer_indicator.text = f'TOP LAYER:{top_layer}'
        self.max_layer_indicator.rebuild()

        self.normal_spots_count.text = f'NORMAL SPOTS:{normal_spots_count}'
        self.normal_spots_count.rebuild()

        self.vibrant_spots_count.text = f'VIBRANT SPOTS:{vibrant_spots_count}'
        self.vibrant_spots_count.rebuild()

        self.explosive_spots_count.text = f'EXPLOSIVE SPOTS:{explosive_spots_count}'
        self.explosive_spots_count.rebuild()

        self.vampire_spots_count.text = f'VAMPIRE SPOTS:{vampire_spots_count}'
        self.vampire_spots_count.rebuild()

    def build_spot_atributes_ui(self,spot,mouse):
        self.spot_atribute_display.set_relative_position((min(520,mouse[0]),
                                                          min(300,mouse[1])))
        self.spot_atribute_display.html_text =  f"""
SIZE:{spot.rect.width}<br>
STATE:{spot.state}<br>
LAYER:{spot.layer}<br>
"""
        self.spot_atribute_display.visible = True
        self.spot_atribute_display.rebuild()

    def update(self,dt):
        self.rebuild_ui()

    def handle_inputs(self,inputs,mouse):
        if inputs[0]:
            if self.inspector.spots:
                top_object = self.inspector.get_top_object(pygame.Rect(mouse[0],mouse[1],1,1))
                if top_object:
                    self.build_spot_atributes_ui(top_object,mouse)
            
        if inputs[2]:
            self.spot_atribute_display.visible = False

    def draw(self,screen):
        self.ui_manager.draw_ui(screen)


class Game:
    """
    Holds all the game elements together and run them thought run method
    """
    def __init__(self):
        pygame.init()
        self.clock = pygame.Clock()
        self.speed = 1000
        self.paused = False
        self.screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.load_constants()
        self.game_rect = pygame.Rect(0,0,SCREEN_WIDTH-self.sidebar_width,SCREEN_HEIGHT)

        self.cosmos = Cosmos()
        self.ui_system = UISystem(self.cosmos.data,self.cosmos.spot_registry)

    def load_constants(self):
        self.sidebar_costants_path = os.path.join('sidebar_constants.json')
        with open(self.sidebar_costants_path) as f:
            self.CONSTANTS = json.load(f)
        self.sidebar_x = self.CONSTANTS["SIDEBAR_X"]
        self.sidebar_y = self.CONSTANTS["SIDEBAR_Y"]
        self.sidebar_width = self.CONSTANTS["SIDEBAR_WIDTH"]
        self.sidebar_height = self.CONSTANTS["SIDEBAR_HEIGHT"]

    def update(self,dt):
        self.cosmos.update(dt)

        self.ui_system.data = self.cosmos.data
        self.ui_system.update(dt)

        if not self.paused:
            self.ui_system.spot_atribute_display.visible = False

    def handle_inputs(self,inputs):
        mouse = pygame.mouse.get_pos()
        if not self.paused and self.game_rect.collidepoint(mouse):
            self.cosmos.interaction_system.shrink_at_point(mouse)

        if self.paused and inputs and self.game_rect.collidepoint(mouse):
            self.ui_system.handle_inputs(inputs,mouse)

    def draw(self):
        self.screen.fill((0,0,0))
        self.cosmos.draw(self.screen)
        self.ui_system.draw(self.screen)
        pygame.display.flip()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame_gui.UI_SELECTION_LIST_NEW_SELECTION:
                    if event.ui_element == self.ui_system.ui_sidebar:
                        if event.text == 'pause':
                            self.paused = True
                        if event.text == 'resume':
                            self.speed = 1000
                            self.paused = False
                        if event.text == 'forward':
                            self.speed = 250
                            self.paused = False
                
                self.ui_system.ui_manager.process_events(event)
            

            inputs = pygame.mouse.get_pressed() 
            dt = self.clock.tick(FPS) / self.speed           

            self.handle_inputs(inputs)
            if not self.paused:
                self.update(dt)
            self.ui_system.ui_manager.update(dt)
            self.draw()
            await asyncio.sleep(0)


game = Game()
asyncio.run(game.run())