import pygame, random, os, sys, csv, json, asyncio
from enum import Enum, auto
from dataclasses import dataclass

SCREEN_WIDTH, SCREEN_HEIGHT = 320, 180 
DISPLAY_WIDTH, DISPLAY_HEIGHT = 960, 540
FPS = 60
TILE_SIZE = 20


@dataclass(frozen=True)
class Direction:
    name : str
    vector : pygame.Vector2
    sprite_index : int


RIGHT = Direction(name='RIGHT',vector=pygame.Vector2(1,0),sprite_index=0)
LEFT = Direction(name='LEFT',vector=pygame.Vector2(-1,0),sprite_index=1)
UP = Direction(name='UP',vector=pygame.Vector2(0,-1),sprite_index=2)
DOWN = Direction(name='DOWN',vector=pygame.Vector2(0,1),sprite_index=3)


class SpriteSheet:
    def __init__(self,sheet,row,col,width,height):
        self.sprites = []
        self.sheet = pygame.image.load(sheet).convert_alpha()
        self.row = row
        self.col = col
        self.width = width
        self.height = height

    def get_sprites(self):
        for c in range(self.col):
            for r in range(self.row):
                self.sprites.append(
                    self.sheet.subsurface(pygame.Rect(r*self.width,c*self.height,self.width,self.height))
                )
        return self.sprites


class AssetsManager:
    instance = None

    def __new__(cls):
        if cls.instance is None:
            cls.instance = super().__new__(cls)
        return cls.instance

    def load(self):
        self.small_pixel = os.path.join('assets','fonts','Tiny5.ttf')

        self.floor_sprite = pygame.image.load(os.path.join('assets','sprites','floor.png')).convert_alpha()
        self.rock_sprite = pygame.image.load(os.path.join('assets','sprites','rock.png')).convert_alpha()
        self.chest_sprite = SpriteSheet(os.path.join('assets','sprites','chest.png'),row=2,col=1,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.player_sprite = SpriteSheet(os.path.join('assets','sprites','player.png'),row=4,col=1,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.goblin_sprite = SpriteSheet(os.path.join('assets','sprites','goblin.png'),row=4,col=1,width=TILE_SIZE,height=TILE_SIZE).get_sprites()

        self.item_background = pygame.image.load(os.path.join('assets','sprites','ItemBackground.png')).convert_alpha()

        self.battle_background = SpriteSheet(os.path.join('assets','sprites','BattleScreen.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.battle_menu = SpriteSheet(os.path.join('assets','sprites','BattleMenu.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()

        self.battle_general_actions = SpriteSheet(os.path.join('assets','sprites','BattleGeneralActions.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.battle_skill_actions = SpriteSheet(os.path.join('assets','sprites','BattleSkillActions.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.battle_item_actions = SpriteSheet(os.path.join('assets','sprites','BattleItemActions.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()

        self.battle_goblin = SpriteSheet(os.path.join('assets','sprites','BattleGoblin.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.battle_overlayer = SpriteSheet(os.path.join('assets','sprites','BattleOverlayer.png'),row=16,col=9,width=TILE_SIZE,height=TILE_SIZE).get_sprites()
        self.battle_pointers = SpriteSheet(os.path.join('assets','sprites','Pointers.png'),row=4,col=1,width=320,height=180).get_sprites()

        self.game_over_screen = pygame.image.load(os.path.join('assets','sprites','GameOver.png')).convert_alpha()
        self.victory_screen = pygame.image.load(os.path.join('assets','sprites','Victory.png')).convert_alpha()


class Tiles(Enum):
    FLOOR = ' '
    ROCK = 'R'
    CHEST = 'C'
    PLAYER = 'P'
    GOBLIN = 'G'


class ChestStatus(Enum):
    CLOSED = 0
    OPENED = 1


class GridTile(pygame.sprite.Sprite):
    def __init__(self,coords,image,group):
        super().__init__(group)
        self.image = image
        self.coords = coords
        self.set_rect()

    def set_rect(self):
        self.pos = self.coords * TILE_SIZE
        self.rect = self.image.get_rect(topleft=self.pos)


class Floor(GridTile):
    pass


class Rock(GridTile):
    pass


class Chest(GridTile):
    def __init__(self, coords, sheet, group, loot=None):
        self.sheet = sheet
        self.status = ChestStatus.CLOSED
        self.loot = loot
        self.just_oppended = False
        image = self.sheet[self.status.value] 
        super().__init__(coords, image, group)

    def open(self,player):
        if self.status == ChestStatus.CLOSED:
            self.status = ChestStatus.OPENED
            self.image = self.sheet[self.status.value] 

            if self.loot:
                player.has_skills.append(self.loot)
                self.just_oppended = True


class Entity(GridTile):
    def __init__(self, coords, sheet, group, dirrection=DOWN.sprite_index):
        self.sheet = sheet
        image = self.sheet[dirrection] 
        self.max_hp = 20
        self.hp = self.max_hp
        super().__init__(coords, image, group)

    def face(self,direction):
        self.image = self.sheet[direction.sprite_index]

    def move(self,direction):
        self.coords += direction.vector
        self.set_rect()

    def on_movement_blocked(self):
        pass


class Player(Entity):
    def __init__(self, coords, sheet, group, dirrection=DOWN.sprite_index):
        super().__init__(coords, sheet, group, dirrection)
        self.has_skills = []
        self.items = 0 
        self.block = False


class Goblin(Entity):
    def __init__(self, coords, sheet, group, dirrection=DOWN.sprite_index):
        self.in_battle = False
        self.walk = RIGHT
        super().__init__(coords, sheet, group, dirrection)
        self.max_hp = 5
        self.hp = self.max_hp
        

    def on_movement_blocked(self):
        if self.walk == RIGHT:
            self.walk = LEFT
        elif self.walk == LEFT:
            self.walk = RIGHT


class GoblinAI:
    def __init__(self):
        self.behaviour = None

    def decide_behaviour(self,goblin,player):
        if goblin.coords.distance_to(player.coords) > 2:
            self.behaviour = self.patrol(goblin)
        else:
            self.behaviour = self.chase(goblin,player)
        return self.behaviour

    def patrol(self,goblin):
        return goblin.walk
    
    def chase(self,goblin,player):
        chase_vector = player.coords - goblin.coords
        if chase_vector.x != 0:
            if chase_vector.x > 0:
                return RIGHT
            elif chase_vector.x < 0:
                return LEFT
            
        if chase_vector.y != 0:
            if chase_vector.y > 0:
                return DOWN
            elif chase_vector.y < 0:
                return UP        


class Camera:
    def __init__(self,x_tiles,y_tiles):
        self.x_tiles = x_tiles
        self.y_tiles = y_tiles
        self.offset = pygame.Vector2()

    def get_offset(self,target):
       room_x = target.coords.x // self.x_tiles
       room_y = target.coords.y // self.y_tiles

       self.offset.x = SCREEN_WIDTH * room_x
       self.offset.y = SCREEN_HEIGHT * room_y

    def apply_offset(self,rect):
        return rect.topleft - self.offset

@dataclass
class RenderLayer:
    sprites : list
    visible : bool


class SceeneStates(Enum):
    ACTIVE = auto()
    ENTERING = auto()
    INACTIVE = auto()
    EXITING = auto()


class Level:
    def __init__(self):
        self.assets = AssetsManager()
        self.assets.load()
        self.background_sprites = pygame.sprite.Group()
        self.visible_sprites = pygame.sprite.Group()
        self.obstacles = [Tiles.ROCK.value,Tiles.CHEST.value,Tiles.GOBLIN.value,Tiles.PLAYER.value]
        with open('level_one.csv') as f:
            self.grid = list(csv.reader(f)) 
           
    def create_map(self):
        self.background_sprites.empty()
        self.visible_sprites.empty()

        for row_index,row in enumerate(self.grid):
            for col_index,col in enumerate(row):
                coords = pygame.Vector2(col_index,row_index)
                if col != Tiles.ROCK.value:
                    Floor(coords,self.assets.floor_sprite,self.background_sprites)
                if col == Tiles.ROCK.value:
                    Rock(coords,self.assets.rock_sprite,self.visible_sprites)
                if col == Tiles.CHEST.value:
                    if (row_index,col_index) == (10,30):
                        Chest(coords,self.assets.chest_sprite,self.visible_sprites,loot='GOBLIN-SLAYER')
                    elif (row_index,col_index) == (13,46):
                        Chest(coords,self.assets.chest_sprite,self.visible_sprites,loot='CROWN')
                    elif (row_index,col_index) == (5,8):
                        Chest(coords,self.assets.chest_sprite,self.visible_sprites,loot='SHIELD')
                    else:
                        Chest(coords,self.assets.chest_sprite,self.visible_sprites)
                if col == Tiles.GOBLIN.value:
                    Goblin(coords,self.assets.goblin_sprite,self.visible_sprites)
                if col == Tiles.PLAYER.value:
                    self.player = Player(coords,self.assets.player_sprite,self.visible_sprites)

    def update_map(self,entity,start_coords,end_coords):
        self.grid[int(start_coords.y)][int(start_coords.x)] = Tiles.FLOOR.value
        if isinstance(entity,Player):
            self.grid[int(end_coords.y)][int(end_coords.x)] = Tiles.PLAYER.value
        elif isinstance(entity,Goblin):
            self.grid[int(end_coords.y)][int(end_coords.x)] = Tiles.GOBLIN.value

    def handle_events(self,event,*args):
        if event == 'move':
            entity = args[0]
            dirrecction = args[1]
            self.move_entity(entity,dirrecction)

    def move_entity(self,entity,direction):
        entity.face(direction)
        start_coords = entity.coords
        end_coords = entity.coords + direction.vector
        if self.movement_blocked(entity,direction):
            entity.on_movement_blocked()
        else:
            self.update_map(entity,start_coords,end_coords)
            entity.move(direction)

    def movement_blocked(self,entity,direction):
        move_to_tile = entity.coords + direction.vector
        checked_tile = self.grid[int(move_to_tile.y)][int(move_to_tile.x)]
        if isinstance(entity,Player) and checked_tile == Tiles.CHEST.value:
            self.get_tile_at_coords(move_to_tile).open(entity)
            return True
        if isinstance(entity,Goblin) and checked_tile == Tiles.PLAYER.value:
            entity.in_battle = True
        return checked_tile in self.obstacles

    def get_tile_at_coords(self,coords):
        for tile in self.visible_sprites:
            if tile.coords == coords:
                return tile


class BattlePhases(Enum):
    INTRO = auto()
    PLAYER_TURN = auto()
    PLAYER_ATTACK_RESOLUTION = auto() 
    ENEMY_TURN = auto()
    ENEMY_ATTACK_RESOLUTION = auto()   
    ESCAPE_RESULT = auto()
    VICTORY_DEFEATED = auto()
    VICTORY_LOOT = auto()
    END = auto()

class BattleActions(Enum):
    ATTACK = auto()
    SKILL = auto()
    ITEM = auto()
    ESCAPE = auto()


class BattleSkills(Enum):
    BLOCK = auto()


class BattleItems(Enum):
    HEAL = auto()
    

class BaseScene:
    def __init__(self):
        self.next_scene = None

    def handle_inputs(self,inputs):
        pass

    def update(self):
        pass

    def draw(self,screen):
        pass


class HealthBar:
    def __init__(self):
        self.assets = AssetsManager()
        self.assets.load()
        self.font = pygame.font.Font(self.assets.small_pixel,16)
        
    def draw(self,player,enemy,screen):
        self.player_max_render = self.font.render(f'{player.max_hp:02d}',False,(128,128,128))
        self.player_current_render = self.font.render(f'{player.hp:02d}',False,(128,128,128))
        screen.blit(self.player_current_render,self.player_current_render.get_rect(center=(21.25,152)))
        screen.blit(self.player_max_render, self.player_max_render.get_rect(center=(21.25,168)))

        self.enemy_max_render = self.font.render(f'{enemy.max_hp:02d}',False,(128,128,128))
        self.enemy_current_render = self.font.render(f'{enemy.hp:02d}',False,(128,128,128))
        screen.blit(self.enemy_current_render,self.enemy_current_render.get_rect(center=(301.25,152)))
        screen.blit(self.enemy_max_render, self.enemy_max_render.get_rect(center=(301.25,168) ))


class TextNaration:
    def __init__(self):
        with open('naration.json') as f:
            self.lines = json.load(f)

        self.assets = AssetsManager()
        self.assets.load()
        self.font = pygame.font.Font(self.assets.small_pixel,20)

    def draw(self,battle_message,screen):
        self.g_a_text = self.font.render(battle_message,False,(128,128,128))
        screen.blit(self.g_a_text,self.g_a_text.get_rect(center=(160,152)))


class BattleVisuals:
    def __init__(self,*layers):
        self.state = SceeneStates.INACTIVE
        self.layers = list(layers)
        self.tiles_visible = 0

    def enter(self):
        if self.state == SceeneStates.INACTIVE:
            self.state = SceeneStates.ENTERING

    def exit(self):
        if self.state == SceeneStates.ACTIVE:
            self.state = SceeneStates.EXITING

    def update(self):
        if self.state == SceeneStates.ENTERING:
            if self.tiles_visible < 144:
                self.tiles_visible += 1
            else:
                self.state = SceeneStates.ACTIVE

        if self.state == SceeneStates.EXITING:
            if self.tiles_visible > 0:
                self.tiles_visible -= 1
            else:
                self.state = SceeneStates.INACTIVE
            
    def draw(self,surface):
        if self.state != SceeneStates.INACTIVE:
            for layer in self.layers:
                if layer.visible:
                    for t in range(self.tiles_visible):
                        surface.blit(
                            layer.sprites[t],
                            (TILE_SIZE * (t%16),TILE_SIZE * (t//16))
                            )


class BattleScene(BaseScene):
    def __init__(self):
        super().__init__()

        self.phase = BattlePhases.INTRO

        # self.actions is now replaced by self.current_menu
        self.actions = [BattleActions.ATTACK, BattleActions.SKILL, BattleActions.ITEM, BattleActions.ESCAPE]
        self.skills = [BattleSkills.BLOCK]
        self.items = [BattleItems.HEAL]

        # Current menu will be set dynamically
        self.current_menu = self.actions  # Default to the general actions
        self.selected_action = 0

        self.battle_message = None
        self.escape_success = False

        self.player = None
        self.enemy = None

        self.hp_bar = HealthBar()
        self.naration = TextNaration()

        self.assets = AssetsManager()
        self.assets.load()
        self.battle_overlayer = RenderLayer(sprites=self.assets.battle_overlayer, visible=True)
        self.battle_background = RenderLayer(sprites=self.assets.battle_background, visible=True)
        self.battle_menu = RenderLayer(sprites=self.assets.battle_menu, visible=True)

        self.battle_general_actions = RenderLayer(sprites=self.assets.battle_general_actions, visible=True)
        self.battle_skill_actions = RenderLayer(sprites=self.assets.battle_skill_actions, visible=False)
        self.battle_item_actions = RenderLayer(sprites=self.assets.battle_item_actions, visible=False)

        self.battle_goblin = RenderLayer(sprites=self.assets.battle_goblin, visible=True)

        self.battle_visuals = BattleVisuals(
            self.battle_background,
            self.battle_menu,
            self.battle_general_actions,
            self.battle_skill_actions,
            self.battle_item_actions,
            self.battle_goblin,
            self.battle_overlayer
        )

        self.battle_pointers = self.assets.battle_pointers

    def reset(self, player, enemy):
        """Reset battle state"""
        self.player = player
        self.enemy = enemy
        self.phase = BattlePhases.INTRO
        self.battle_message = "Wild goblin approaches!"
        
        # Reset UI visibility
        self.battle_overlayer.visible = True
        self.battle_general_actions.visible = True
        self.battle_skill_actions.visible = False
        self.battle_item_actions.visible = False
        
        # Reset menu selection
        self.current_menu = self.actions
        self.selected_action = 0
        
        # Reset visuals state
        self.battle_visuals.tiles_visible = 0
        self.battle_visuals.state = SceeneStates.INACTIVE

    def handle_inputs(self, inputs):
        if self.battle_visuals.state != SceeneStates.ACTIVE:
            return

        if self.phase == BattlePhases.INTRO:
            if inputs[pygame.K_SPACE]:
                self.phase = BattlePhases.PLAYER_TURN
                self.battle_message = None
                self.battle_overlayer.visible = False

        elif self.phase == BattlePhases.PLAYER_TURN:
            if inputs[pygame.K_RIGHT]:
                self.selected_action = (self.selected_action + 1) % len(self.current_menu)
            if inputs[pygame.K_LEFT]:
                self.selected_action = (self.selected_action - 1) % len(self.current_menu)

            if inputs[pygame.K_SPACE]:
                if self.current_menu == self.actions:
                    if self.actions[self.selected_action] == BattleActions.SKILL and 'SHIELD' in self.player.has_skills:
                        self.selected_action = 0
                        self.current_menu = self.skills
                        self.battle_general_actions.visible = False
                        self.battle_skill_actions.visible = True
                    elif self.actions[self.selected_action] == BattleActions.ITEM and self.player.items:
                        self.selected_action = 0
                        self.current_menu = self.items
                        self.battle_general_actions.visible = False
                        self.battle_item_actions.visible = True
                    else:
                        self.execute_action(self.actions[self.selected_action])

                elif self.current_menu == self.skills:  # Skill menu
                    self.execute_skill()
                elif self.current_menu == self.items:  # Item menu
                    self.use_item()
########
        elif self.phase == BattlePhases.PLAYER_ATTACK_RESOLUTION:
                    if inputs[pygame.K_SPACE]:
                        # If enemy is dead, go to the first victory message
                        if self.enemy.hp <= 0:
                            self.battle_message = "Goblin is defeated!"
                            self.phase = BattlePhases.VICTORY_DEFEATED
                        else:
                            self.battle_message = None
                            self.battle_overlayer.visible = False
                            self.phase = BattlePhases.ENEMY_TURN

        elif self.phase == BattlePhases.VICTORY_DEFEATED:
            if inputs[pygame.K_SPACE]:
                # Second victory message: Gaining loot
                self.player.items += 1 # Or whatever your loot logic is
                self.battle_message = "Gained goblin flesh"
                self.phase = BattlePhases.VICTORY_LOOT

        elif self.phase == BattlePhases.VICTORY_LOOT:
            if inputs[pygame.K_SPACE]:
                # Final step: Close the message and trigger the exit
                self.battle_message = None
                self.battle_overlayer.visible = False
                self.enemy.in_battle = False # Ensure enemy is flagged as out of battle
                self.battle_visuals.exit() 
                self.phase = BattlePhases.END
#
        elif self.phase == BattlePhases.ENEMY_ATTACK_RESOLUTION:
            if inputs[pygame.K_SPACE]:
                self.battle_message = None
                self.battle_overlayer.visible = False
                self.phase = BattlePhases.PLAYER_TURN

        elif self.phase == BattlePhases.ESCAPE_RESULT:
            if inputs[pygame.K_SPACE]:
                if self.escape_success:
                    self.battle_visuals.exit()
                    self.phase = BattlePhases.END
                else:
                    self.battle_message = None
                    self.battle_overlayer.visible = False
                    self.phase = BattlePhases.ENEMY_TURN

        elif self.phase == BattlePhases.END:
            if inputs[pygame.K_SPACE]:
                self.battle_visuals.exit()


    def execute_action(self, action):
        if action == BattleActions.ATTACK:
            self.player_attack()        
        elif action == BattleActions.SKILL:
            if self.skills:
                pass
        elif action == BattleActions.ITEM:
            if self.items:
                pass
        elif action == BattleActions.ESCAPE:
            self.try_escape()

    def execute_skill(self):
        self.battle_message = "Player blocks incoming attack!"
        self.player.block = True
        self.battle_overlayer.visible = True

        self.selected_action = 0
        self.current_menu = self.actions
        self.battle_general_actions.visible = True
        self.battle_skill_actions.visible = False

        self.phase = BattlePhases.PLAYER_ATTACK_RESOLUTION

    def use_item(self):
        self.player.hp = min(self.player.hp + 5, self.player.max_hp)
        self.player.items -= 1
        self.battle_message = "Health"
        self.battle_overlayer.visible = True

        self.selected_action = 0
        self.current_menu = self.actions
        self.battle_general_actions.visible = True
        self.battle_item_actions.visible = False

        self.phase = BattlePhases.PLAYER_ATTACK_RESOLUTION

    def enemy_attack(self):
        if not self.player.block: 
            if random.randrange(20) > 8:
                damage = random.randrange(1, 6)
                self.player.hp -= damage
                self.battle_message = f'Goblin attacks for {damage} damage!'
            else:
                self.battle_message = "Goblin missed!"
        else:
            self.battle_message = "Goblin hit the shield!"

        self.battle_overlayer.visible = True
        self.phase = BattlePhases.ENEMY_ATTACK_RESOLUTION

    def player_attack(self):
            if 'GOBLIN-SLAYER' not in self.player.has_skills:
                hit_roll = random.randrange(20)
                if hit_roll > 4:
                    damage = random.randrange(2, 5)
                    self.enemy.hp -= damage
                    self.battle_message = f'Attack dealt {damage} damage'
                else:
                    self.battle_message = "Attack missed"

            else:
                damage = 99
                self.enemy.hp -= damage
                self.battle_message = f'Attack dealt {damage} damage'

            self.battle_overlayer.visible = True
            # Always go to resolution first to show the damage message
            self.phase = BattlePhases.PLAYER_ATTACK_RESOLUTION

    def try_escape(self):
        self.escape_success = random.randrange(20) > 6

        if self.escape_success:
            self.battle_message = "Escaped successfully!"
        else:
            self.battle_message = "Escape failed!"

        self.battle_overlayer.visible = True
        self.phase = BattlePhases.ESCAPE_RESULT

    def update(self):
        self.battle_visuals.update()


        if self.phase == BattlePhases.ENEMY_TURN:
            self.enemy_attack()

        if self.player.hp <=0:
            self.next_scene = 'GAME_OVER'

        if self.battle_visuals.state == SceeneStates.INACTIVE:
            self.next_scene = 'OVERWORLD'

    def draw(self, screen):
        self.battle_visuals.draw(screen)

        if self.battle_visuals.state == SceeneStates.ACTIVE:
            if self.battle_message:
                self.naration.draw(self.battle_message, screen)

            if not self.battle_overlayer.visible:
                self.hp_bar.draw(self.player, self.enemy, screen)
                screen.blit(self.battle_pointers[self.selected_action], (0, 0))

        

class Overworld(BaseScene):
    def __init__(self):
        super().__init__()
        self.level = Level()
        self.level.create_map()
        self.assets = AssetsManager()
        self.assets.load()
        self.naration = TextNaration()
        self.goblin_ai = GoblinAI()
        self.camera = Camera(16, 9)

    def reset(self):
        # Reset all NPCs, including Goblins
        for npc in self.level.visible_sprites:
            if isinstance(npc, Goblin):
                npc.hp = npc.max_hp
                npc.in_battle = False

    def movement_request(self,entity,direction):
        self.level.handle_events('move',entity,direction)
        for npc in self.level.visible_sprites:
            if isinstance(npc,Goblin):
                self.level.handle_events('move',npc,self.goblin_ai.decide_behaviour(npc,self.level.player))

    def handle_inputs(self,inputs):
        direction = None
        if inputs[pygame.K_RIGHT]:
            direction = RIGHT
        elif inputs[pygame.K_LEFT]:
            direction = LEFT
        elif inputs[pygame.K_UP]:
            direction = UP
        elif inputs[pygame.K_DOWN]:
            direction = DOWN

        if direction:
            self.clear_item_messages()
            self.movement_request(self.level.player,direction)

        if inputs[pygame.K_SPACE]:
            self.clear_item_messages()

    def clear_item_messages(self):
        for sprite in self.level.visible_sprites:
            if isinstance(sprite, Chest) and sprite.just_oppended:
                if sprite.loot == 'CROWN':  # Check if the crown was collected
                    self.next_scene = 'VICTORY'  # Switch to victory screen
                sprite.just_oppended = False

    def update(self):
        self.camera.get_offset(self.level.player)

        # Cleanup goblins if they are dead
        for npc in list(self.level.visible_sprites):  # use list() to safely remove while iterating
            if isinstance(npc, Goblin) and npc.hp <= 0:
                # Remove from overworld grid
                self.level.grid[int(npc.coords.y)][int(npc.coords.x)] = Tiles.FLOOR.value
                # Remove sprite from group
                npc.kill()

        for npc in self.level.visible_sprites:
            if isinstance(npc, Goblin) and npc.in_battle:
                self.next_scene = 'BATTLE'
        
    def draw(self, screen):
        screen.fill((128, 128, 128))
        for sprite in self.level.background_sprites:
            screen.blit(sprite.image, self.camera.apply_offset(sprite.rect))
        for sprite in self.level.visible_sprites:
            screen.blit(sprite.image, self.camera.apply_offset(sprite.rect))

        for tile in self.level.visible_sprites:
            if isinstance(tile, Chest) and tile.just_oppended:
                screen.blit(self.assets.item_background, (0, 0))
                self.naration.draw(f'YOU RECEIVED A {tile.loot}!', screen)

class GameOver(BaseScene):
    def __init__(self):
        super().__init__()
        self.assets = AssetsManager()
        self.assets.load()

    def handle_inputs(self, inputs):
        if inputs[pygame.K_SPACE]:  # Press R to restart
            self.next_scene = 'OVERWORLD'

    def draw(self, screen):
        screen.blit(self.assets.game_over_screen, (0, 0))
        

class Victory(BaseScene):
    def __init__(self):
        super().__init__()
        self.assets = AssetsManager()
        self.assets.load()

    def handle_inputs(self, inputs):
        if inputs[pygame.K_SPACE]: 
            self.next_scene = 'OVERWORLD'

    def draw(self, screen):
        screen.blit(self.assets.victory_screen, (0, 0))

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.display = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT))
        self.clock = pygame.Clock()

        # Initialize the scenes
        self.overworld_scene = Overworld()
        self.battle_scene = BattleScene()
        self.game_over_scene = GameOver()
        self.victory_scene = Victory()

        # Set the current scene
        self.current_scene = self.overworld_scene

    def reset_game(self):
        # This creates a fresh Level, which reads the CSV and creates the map once
        self.overworld_scene = Overworld() 

        self.battle_scene = BattleScene()
        
        # Ensure current_scene is updated
        self.current_scene = self.overworld_scene

    async def run(self):
        while True:
            # Collect KEYDOWN events into a set this frame
            just_pressed_keys = set()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    just_pressed_keys.add(event.key)

            # Wrap the set so that inputs[pygame.K_SPACE] still works
            # everywhere in your scene code without any other changes
            class Inputs:
                def __getitem__(self, key):
                    return key in just_pressed_keys

            inputs = Inputs()

            self.current_scene.handle_inputs(inputs)
            self.current_scene.update()

            if self.current_scene.next_scene == 'BATTLE':
                self.current_scene.next_scene = None

                # Find the enemy that triggered the battle
                target_enemy = None
                for npc in self.current_scene.level.visible_sprites:
                    if isinstance(npc, Goblin) and npc.in_battle:
                        target_enemy = npc
                        break

                # Reset the battle scene with the current player and target enemy
                self.battle_scene.reset(self.current_scene.level.player, target_enemy)

                # Switch scene and start transition
                self.current_scene = self.battle_scene
                self.current_scene.battle_visuals.enter()

            elif self.current_scene.next_scene == 'OVERWORLD':
                self.current_scene.next_scene = None
                if self.current_scene == self.game_over_scene or self.current_scene == self.victory_scene:
                    self.reset_game()  # Reset the game when going back to the overworld
                self.current_scene = self.overworld_scene

            elif self.current_scene.next_scene == 'GAME_OVER':
                self.current_scene.next_scene = None
                self.current_scene = self.game_over_scene

            elif self.current_scene.next_scene == 'VICTORY':  # Check for victory
                self.current_scene.next_scene = None
                self.current_scene = self.victory_scene

            self.overworld_scene.draw(self.screen)
            if self.current_scene == self.battle_scene:
                self.current_scene.draw(self.screen)
            elif self.current_scene == self.game_over_scene:
                self.current_scene.draw(self.screen)
            elif self.current_scene == self.victory_scene:
                self.current_scene.draw(self.screen)

            self.display.blit(pygame.transform.scale(self.screen, self.display.get_rect().size), (0, 0))
            pygame.display.flip()
            self.clock.tick(FPS)
            await asyncio.sleep(0)
            
game = Game()
asyncio.run(game.run())