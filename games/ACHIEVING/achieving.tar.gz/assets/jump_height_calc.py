import matplotlib.pyplot as plt
import numpy as np

size = 20
j_range = np.arange(1, size + 1)
g_range = np.arange(1, size + 1)

def calculate_jump(jump_force, gravity):
    if gravity <= 0: return 0
    vel_y = jump_force
    pos_y = vel_y
    max_y = pos_y
    while pos_y > 0:
        vel_y -= gravity
        pos_y += vel_y
        if pos_y > max_y:
            max_y = pos_y
    return int(max_y)

def matching_value_search(min_value):
    matches = []
    matches.sort
    for j in j_range:
        for g in g_range:
            max_y = calculate_jump(j,g)
            if max_y >= min_value:
                matches.append([j,g,max_y])
    matches.sort(key=lambda sublist: sublist[2])
    for m in matches:
        print(f'J={m[0]} ||| G={m[1]} ||| MAX_Y={m[2]}')

def draw_heatmap():
    # 1. Expand range to 1-30
    # done at the top

    # 2. Fill the 30x30 matrix
    Z = np.zeros((len(g_range), len(j_range)))
    for i, g in enumerate(g_range):
        for j, jf in enumerate(j_range):
            Z[i, j] = calculate_jump(jf, g)

    # 3. Plotting (Larger figure for more data)
    plt.figure(figsize=(14, 12))

    # Adjusting extent to match the 1-30 labels
    im = plt.imshow(Z, origin='lower', extent=[0.5, size + 0.5, 0.5, size + 0.5], cmap='viridis')

    # 4. Set ticks for every integer
    plt.xticks(j_range, fontsize=8)
    plt.yticks(g_range, fontsize=8)

    # 5. Add text (Smaller font size to fit 30x30 grid)
    for (i, j), val in np.ndenumerate(Z):
        plt.text(j+1, i+1, int(val), ha='center', va='center', 
                fontsize=7,
                color='white' if val < Z.max()/2 else 'black')

    plt.xlabel('Jump Force', fontsize=12)
    plt.ylabel('Gravity', fontsize=12)
    plt.title(f'Jump Height Lookup ({size}x{size})', fontsize=14)
    plt.colorbar(im, label='Max Y Height')

    # Add a subtle grid to help guide the eye
    plt.grid(visible=True, which='both', color='white', linestyle='-', linewidth=0.2, alpha=0.5)

    plt.show()

def get_data(form):
    if form == 'map':
       draw_heatmap() 
    if form == 'match':
        matching_value_search(112)


calc_mode = input('type map or match \n >')
get_data(calc_mode)