import pygame,random
from .globals import *

class ColisionManger:
    def __init__(self):
        self.event_resolution = {
        ('player', 'jumporb') : self.resolve_jumporb_colision,
        ('player', 'dashorb') : self.resolve_dashorb_colision,
        ('player', 'flag') : self.resolve_flag_colision,
        ('player', 'key') : self.resolve_key_colision,
        ('player', 'trigger') : self.resolve_trigger_colision,
        ('player', 'spike') : self.resolve_spike_colision,
        ('player', 'virus') : self.resolve_virus_colision,
        ('player', 'error') : self.resolve_spike_colision,

        ('player', 'aboss') : self.resolve_spike_colision,
        ('player', 'cboss') : self.resolve_spike_colision,
        ('player', 'hboss') : self.resolve_spike_colision,
        ('player', 'iboss') : self.resolve_spike_colision,
        ('player', 'eboss') : self.resolve_spike_colision,
        ('player', 'vboss') : self.resolve_spike_colision,
        ('player', 'inboss') : self.resolve_spike_colision,
        ('player', 'nboss') : self.resolve_spike_colision,
        ('player', 'gboss') : self.resolve_spike_colision,

        ('aboss', 'spike') : self.resolve_spike_colision,
        ('cboss', 'spike') : self.resolve_spike_colision,
        ('hboss', 'spike') : self.resolve_spike_colision,
        ('iboss', 'spike') : self.resolve_spike_colision,
        ('eboss', 'spike') : self.resolve_spike_colision,
        ('vboss', 'spike') : self.resolve_spike_colision,
        ('inboss', 'spike') : self.resolve_spike_colision,
        ('nboss', 'spike') : self.resolve_spike_colision,
        ('gboss', 'spike') : self.resolve_spike_colision,
        }

    def handle_events(self,events):
        for (obj, other) in events:
            resolution =  self.event_resolution.get((obj.type, other.type))
            if not resolution:
                continue
            resolution(obj,other)

    def resolve_jumporb_colision(self,obj,other):
        if not other.active:
            return
        random.choice(SOUND_LIBRARY['pickup']).play()
        obj.jump_count += 1
        other.trigger()

    def resolve_dashorb_colision(self,obj,other):
        if not other.active:
            return
        random.choice(SOUND_LIBRARY['pickup']).play()
        obj.end_dash_cooldown()
        other.trigger()

    def resolve_flag_colision(self,obj,other): 
        other.trigger()

    def resolve_key_colision(self,obj,other): 
        random.choice(SOUND_LIBRARY['pickup']).play()
        other.trigger()

    def resolve_trigger_colision(self,obj,other):
        if other.activated:
            return
        SOUND_LIBRARY['trigger'].play()
        other.trigger()

    def resolve_spike_colision(self,obj,other):
        if obj.type != 'player':
            if obj.alive():
                SOUND_LIBRARY['hit'].play()
        obj.die()

    def resolve_virus_colision(self,obj,other):
        obj.die()