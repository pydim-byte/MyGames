import pygame
from pytmx.util_pygame import load_pygame
from .globals import *
from .objects.tile import Tile
from .objects.player import Player
from .objects.flag import Flag
from .objects.jump_orb import JumpOrb
from .objects.dash_orb import DashOrb
from .objects.key import Key
from .objects.lock import Lock
from .objects.platform import Platform
from .objects.trigger import Trigger
from .objects.spike import Spike
from .objects.virus import Virus
from .objects.a_boss import ABoss
from .objects.c_boss import CBoss
from .objects.i_boss import IBoss
from .objects.h_boss import HBoss
from .objects.e_boss import EBoss
from .objects.v_boss import VBoss
from .objects.n_boss import NBoss
from .objects.in_boss import InBoss
from .objects.g_boss import GBoss
from .objects.error import Error

class Tilemap:
    def __init__(self,level=1):
        self.level_path = f'assets/tilemap/level_{level}.tmx'
        self.tmx_data = load_pygame(self.level_path)
        self.all_sprites = pygame.sprite.Group()
        self.visible_tiles = pygame.sprite.Group()
        self.player = pygame.sprite.GroupSingle()
        self.flags = pygame.sprite.Group()
        self.active_flag = pygame.sprite.GroupSingle()
        self.jump_orbs = pygame.sprite.Group()
        self.keys = pygame.sprite.Group()
        self.locks = pygame.sprite.Group()
        self.viruses = pygame.sprite.Group()
        self.bosses = pygame.sprite.Group()
        
        self.final_message = pygame.sprite.Group()
        self.final_message_trigger = None

        self.warnings = pygame.sprite.Group()
        self.errors = pygame.sprite.Group()

        self.late_viruses = pygame.sprite.Group()

        self.platforms = []
        self.spikes = []
        self.kinematic_sprites = []
        self.static_sprites = []
        self.get_tiles()

    @property
    def respawn_point(self):
        return self.active_flag.sprite.pos.copy()

    def show_hiden_layer(self,layer):
        self.all_sprites.add(layer)

    def set_active_flag(self,flag):
        self.active_flag.add(flag)

    def unlock(self,key_id):
        for lock in self.locks:
            if lock.lock_id == key_id:
                lock.kill()

    def show_warning(self):
        self.all_sprites.add(self.warnings)

    def hide_warning(self):
        self.all_sprites.remove(self.warnings)
        self.all_sprites.add(self.errors)
        self.static_sprites.extend(self.errors)

    def spawn_virus(self):
        self.all_sprites.add(self.late_viruses)
        self.kinematic_sprites.extend(self.late_viruses)

    def get_tiles(self):
        for layer in self.tmx_data.visible_layers:
            if hasattr(layer, 'data'):
                layer_type = layer.properties.get('layer_type')
                start_visible = layer.properties.get('start_visible')
                for x, y, img in layer.tiles():
                    pos = pygame.Vector2(x * TILE_SIZE * TILE_SCALE, y * TILE_SIZE * TILE_SCALE)
                    img = pygame.transform.scale_by(img, TILE_SCALE)
                    images = [img]
                    if start_visible:
                        self.visible_tiles.add(Tile(pos, images))
                    else:
                        if layer_type == 'final_message':
                            self.final_message.add(Tile(pos, images))
                        if layer_type == 'warning':
                            self.warnings.add(Tile(pos,images))

        for obj in self.tmx_data.objects:
            pos = pygame.Vector2(obj.x*TILE_SCALE,obj.y*TILE_SCALE)
            images = self.get_images(obj.properties['obj_type'],obj.properties['images_variation'])
            if obj.properties['obj_type'] == 'player':
                self.player.add(Player(pos,images,lambda : self.respawn_point))
            if obj.properties['obj_type'] == 'virus':
                direction_x = obj.properties['direction_x']
                direction_y = obj.properties['direction_y']
                virus_direction = pygame.Vector2(direction_x,direction_y)
                self.viruses.add(Virus(pos,images,virus_direction))
            if obj.properties['obj_type'] == 'save_flag':
                flag = Flag(pos,images,self.set_active_flag)
                self.flags.add(flag)
                if obj.properties['active']:
                    self.set_active_flag(flag)

            if obj.properties['obj_type'] == 'a_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(ABoss(pos,images,target))

            if obj.properties['obj_type'] == 'c_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(CBoss(pos,images,target))

            if obj.properties['obj_type'] == 'h_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(HBoss(pos,images,target))

            if obj.properties['obj_type'] == 'i_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(IBoss(pos,images,target))

            if obj.properties['obj_type'] == 'e_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                error_image = self.get_images('error',1)
                errors_to_spawn = obj.properties['errors_to_spawn']

                for i in range(errors_to_spawn):
                    error_x = obj.properties[f'error_x_{i}'] * TILE_SCALE
                    error_y = obj.properties[f'error_y_{i}'] * TILE_SCALE
                    error_pos = pygame.Vector2(error_x,error_y)
                    self.errors.add(Error(error_pos,error_image))

                self.bosses.add(EBoss(pos,images,target,self.show_warning,self.hide_warning))

            if obj.properties['obj_type'] == 'v_boss':
                target = obj.properties['y_target'] * TILE_SCALE

                virus_image = self.get_images('virus',1)

                virus_x = obj.properties['virus_x'] * TILE_SCALE
                virus_y = obj.properties['virus_y'] * TILE_SCALE
                virus_direction_x = obj.properties['direction_x']
                virus_direction_y = obj.properties['direction_y']
                virus_pos = pygame.Vector2(virus_x,virus_y)
                virus_direction = pygame.Vector2(virus_direction_x,virus_direction_y)
                self.late_viruses.add(Virus(virus_pos,virus_image,virus_direction))

                self.bosses.add(VBoss(pos,images,target,self.spawn_virus))

            if obj.properties['obj_type'] == 'in_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(InBoss(pos,images,target))

            if obj.properties['obj_type'] == 'n_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(NBoss(pos,images,target))

            if obj.properties['obj_type'] == 'g_boss':
                target = obj.properties['y_target'] * TILE_SCALE
                self.bosses.add(GBoss(pos,images,target))

            if obj.properties['obj_type'] == 'jump_orb':
                self.jump_orbs.add(JumpOrb(pos,images))
            if obj.properties['obj_type'] == 'dash_orb':
                self.jump_orbs.add(DashOrb(pos,images))
            if obj.properties['obj_type'] == 'key':
                key_id = obj.properties['key_id']
                key = Key(pos,images,key_id,self.unlock)
                self.keys.add(key)
            if obj.properties['obj_type'] == 'lock':
                lock_id = obj.properties['lock_id']
                self.locks.add(Lock(pos,images,lock_id))
            if obj.properties['obj_type'] == 'platform':
                self.platforms.append(Platform(obj.x * TILE_SCALE,
                                               obj.y * TILE_SCALE,
                                               obj.width * TILE_SCALE,
                                               obj.height * TILE_SCALE))
            if obj.properties['obj_type'] == 'final_message_trigger':
                self.final_message_trigger = (Trigger(obj.x * TILE_SCALE,
                                               obj.y * TILE_SCALE,
                                               obj.width * TILE_SCALE,
                                               obj.height * TILE_SCALE,
                                               self.show_hiden_layer,self.final_message))
            if obj.properties['obj_type'] == 'spike':
                self.platforms.append(Spike(obj.x * TILE_SCALE,
                                               obj.y * TILE_SCALE,
                                               obj.width * TILE_SCALE,
                                               obj.height * TILE_SCALE))
                

        self.all_sprites.add(self.visible_tiles)
        self.all_sprites.add(self.flags)
        self.all_sprites.add(self.jump_orbs)
        self.all_sprites.add(self.keys)
        self.all_sprites.add(self.locks)
        self.all_sprites.add(self.player)
        self.all_sprites.add(self.viruses)
        self.all_sprites.add(self.bosses)

        self.kinematic_sprites.append(self.player.sprite)
        self.kinematic_sprites.extend(self.viruses)
        self.kinematic_sprites.extend(self.bosses)
        self.static_sprites.extend(self.visible_tiles)
        self.static_sprites.extend(self.locks)
        self.static_sprites.extend(self.platforms)
        self.static_sprites.extend(self.flags)      
        self.static_sprites.extend(self.jump_orbs)  
        self.static_sprites.extend(self.keys) 
        self.static_sprites.append(self.final_message_trigger)  

    def get_images(self,name,count):
        images = []
        for i in range(count):
            img = pygame.image.load(f'assets/images/{name}/{i}.png').convert_alpha()
            img = pygame.transform.scale_by(img, TILE_SCALE) 
            images.append(img)
        return images   
