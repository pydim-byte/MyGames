# src/physics_manager.py

import pygame
from .globals import *
from .quadtree import QuadTree

class PhysicsManager:
    def __init__(self, kinematic_objs, static_objs):
        self.kinematic_objs = kinematic_objs
        self.static_objs    = static_objs
        # Match this to your world/tilemap dimensions
        world_bounds = pygame.Rect(0, 0, SCREEN_WIDTH*3, SCREEN_HEIGHT)
        self.qt = QuadTree(0, world_bounds)

    # -------------------------------------------------------------- #
    def _build_tree(self):
        self.qt.clear()
        for obj in self.collidable_objs:
            if obj.alive():
                self.qt.insert(obj)

    # -------------------------------------------------------------- #
    @property
    def collidable_objs(self):
        return self.kinematic_objs + self.static_objs

    # -------------------------------------------------------------- #
    def horizontal_collisions(self, obj):
        for collidable in self.qt.query(obj.rect):   # ← quadtree query
            if collidable is obj:       continue
            if not collidable.alive():  continue
            if not collidable.is_solid: continue
            if not obj.rect.colliderect(collidable.rect): continue

            if obj.vel.x > 0:
                obj.rect.right = collidable.rect.left
                obj.collisions['right'] = True
            elif obj.vel.x < 0:
                obj.rect.left = collidable.rect.right
                obj.collisions['left'] = True
        obj.pos.x = obj.rect.x

    def vertical_collisions(self, obj):
        for collidable in self.qt.query(obj.rect):   # ← quadtree query
            if collidable is obj:       continue
            if not collidable.alive():  continue
            if not collidable.is_solid: continue
            if not obj.rect.colliderect(collidable.rect): continue

            if obj.vel.y > 0:
                obj.rect.bottom = collidable.rect.top
                obj.collisions['bottom'] = True
            elif obj.vel.y < 0:
                obj.rect.top = collidable.rect.bottom
                obj.collisions['top'] = True
        obj.pos.y = obj.rect.y

    def check_on_ground(self, obj):
        ground_check = obj.rect.move(0, 1)
        for collidable in self.qt.query(ground_check): # ← quadtree query
            if collidable is obj:       continue
            if not collidable.alive():  continue
            if not collidable.is_solid: continue
            if not ground_check.colliderect(collidable.rect): continue
            obj.collisions['bottom'] = True

    def check_on_celing(self, obj):
        ceil_check = obj.rect.move(0, -1)
        for collidable in self.qt.query(ceil_check):   # ← quadtree query
            if collidable is obj:       continue
            if not collidable.alive():  continue
            if not collidable.is_solid: continue
            if not ceil_check.colliderect(collidable.rect): continue
            obj.collisions['top'] = True

    def post_move_collisions(self, obj):
        events = []
        for collidable in self.qt.query(obj.rect):     # ← quadtree query
            if collidable is obj:        continue
            if not collidable.alive():   continue
            if collidable.is_solid:      continue
            if not collidable.rect.colliderect(obj.rect): continue
            events.append((obj, collidable))
        return events

    # -------------------------------------------------------------- #
    def move_and_collide(self, obj):
        obj.move_horizontaly()
        self.horizontal_collisions(obj)
        obj.move_verticaly()
        self.vertical_collisions(obj)
        self.check_on_ground(obj)
        self.check_on_celing(obj)
        return self.post_move_collisions(obj)

    def move(self, obj):
        obj.calculate_velocity()
        events = self.move_and_collide(obj)
        obj.resolve_collisions()
        return events

    def fixed_update(self):
        self._build_tree()          # ← rebuild once per physics tick
        events = []
        for obj in self.kinematic_objs:
            events.extend(self.move(obj))
        return events