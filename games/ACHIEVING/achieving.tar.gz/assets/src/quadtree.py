import pygame

class QuadTree:
    MAX_OBJECTS = 5   # objects before splitting
    MAX_LEVELS  = 6   # deepest subdivision allowed

    def __init__(self, level: int, bounds: pygame.Rect):
        self.level   = level
        self.bounds  = bounds
        self.objects = []          # objects in THIS node
        self.nodes   = []          # 4 children (empty until split)

    # ------------------------------------------------------------------ #
    def clear(self):
        self.objects.clear()
        for node in self.nodes:
            node.clear()
        self.nodes.clear()

    # ------------------------------------------------------------------ #
    def _split(self):
        x, y, w, h = self.bounds.x, self.bounds.y, self.bounds.width // 2, self.bounds.height // 2
        lvl = self.level + 1
        self.nodes = [
            QuadTree(lvl, pygame.Rect(x + w, y,     w, h)),  # top-right
            QuadTree(lvl, pygame.Rect(x,     y,     w, h)),  # top-left
            QuadTree(lvl, pygame.Rect(x,     y + h, w, h)),  # bottom-left
            QuadTree(lvl, pygame.Rect(x + w, y + h, w, h)),  # bottom-right
        ]

    # ------------------------------------------------------------------ #
    def _get_indexes(self, rect: pygame.Rect) -> list[int]:
        """Return which quadrant(s) a rect belongs to (-1 = straddles boundary)."""
        indexes   = []
        mid_x     = self.bounds.x + self.bounds.width  // 2
        mid_y     = self.bounds.y + self.bounds.height // 2

        top    = rect.bottom <= mid_y
        bottom = rect.top    >= mid_y
        left   = rect.right  <= mid_x
        right  = rect.left   >= mid_x

        if top    and right: indexes.append(0)
        if top    and left:  indexes.append(1)
        if bottom and left:  indexes.append(2)
        if bottom and right: indexes.append(3)

        return indexes if indexes else [-1]  # straddles: stays in parent

    # ------------------------------------------------------------------ #
    def insert(self, obj) -> None:
        # If we have children, delegate immediately
        if self.nodes:
            for idx in self._get_indexes(obj.rect):
                if idx != -1:
                    self.nodes[idx].insert(obj)
                    return
            # straddles a boundary → keep in this node
            self.objects.append(obj)
            return

        self.objects.append(obj)

        # Split when full and not at max depth
        if len(self.objects) > self.MAX_OBJECTS and self.level < self.MAX_LEVELS:
            self._split()
            # Re-distribute existing objects into children
            remaining = []
            for o in self.objects:
                placed = False
                for idx in self._get_indexes(o.rect):
                    if idx != -1:
                        self.nodes[idx].insert(o)
                        placed = True
                        break
                if not placed:
                    remaining.append(o)
            self.objects = remaining

    # ------------------------------------------------------------------ #
    def query(self, rect: pygame.Rect) -> list:
        """Return all objects that *could* collide with rect."""
        result = list(self.objects)  # always include this node's straddlers

        if self.nodes:
            for idx in self._get_indexes(rect):
                if idx != -1:
                    result.extend(self.nodes[idx].query(rect))
                else:
                    # rect straddles → query all children
                    for node in self.nodes:
                        result.extend(node.query(rect))
                    break  # avoid duplicate queries

        return result