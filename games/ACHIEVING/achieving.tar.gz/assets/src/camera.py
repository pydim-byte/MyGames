import pygame
from .globals import *

class Camera:
    def __init__(self):
        self.offset = pygame.Vector2(0,0)

    def get_offset(self,target):
        level_chunk = (target.rect.centerx - SCREEN_WIDTH)//(SCREEN_WIDTH) + 1
        self.offset.x = SCREEN_WIDTH * level_chunk
        self.offset.x = max(0,self.offset.x)
        self.offset.y = 0
        return self.offset