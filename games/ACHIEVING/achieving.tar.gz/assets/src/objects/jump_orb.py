from .tile import Tile


class JumpOrb(Tile):
    def __init__(self, pos, images):
        super().__init__(pos, images)
        self.active = True
        self.inactive_time = 0
        self.reset_time = 1

    def trigger(self):
        self.active = False
    
    def cooldown(self,dt):
        if self.active:
            return
        if self.inactive_time >= self.reset_time:
            self.active = True
            self.inactive_time = 0
            return
        self.inactive_time += dt

    def update(self,dt):
        self.cooldown(dt)

    def draw(self, surf, offset,alpha):
        if not self.active:
            return
        return super().draw(surf,offset,alpha)