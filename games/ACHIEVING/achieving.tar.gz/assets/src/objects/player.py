import pygame,random
from .kinematic_object import KinematicObject
from ..globals import *


class Player(KinematicObject):
    def __init__(self, pos, images, respawn_pos):
        super().__init__(pos, images)
        # physical atributes
        self.jump_vel = KINEMATIC_OBJECTS_STATS[type(self).__name__.lower()]['jump_vel']
        self.wall_slide_vel = KINEMATIC_OBJECTS_STATS[type(self).__name__.lower()]['wall_slide_vel']
        # abilities atributes
        self.max_jumps = PLAYER_ABILITIES['jump']['count']
        self.jump_count = self.max_jumps
        # state atributes
        self.respawn_pos = respawn_pos
        self.frozen = False
        self.died = False
        self.gravity_inverted = False
        self.horizontal_flip = [True,False]
        self.vertical_flip = [True,False]
        self.animating = {'active' : True, 'current_duration' : 0.0, 'max_duration' : 0.1, 'current_frame' : 0}
        self.coyote_time = {'active' : False, 'current_duration' : 0.0, 'max_duration' : 0.1}
        self.last_wall_direction = 0
        self.wall_coyote_time = {'active' : False, 'current_duration' : 0.0, 'max_duration' : 0.1}
        self.wall_jumping =  {'active' : False, 'current_duration' : 0.0, 'max_duration' : 0.2}
        self.dashing = {'active' : False, 'current_duration' : 0.0, 'max_duration' : 0.1, 'dash_direction' : 0}
        self.dash_cooldown = {'active' : False, 'current_duration' : 0.0, 'max_duration' : 0.5}

    @property
    def horizontal_movement_direction(self):
        if self.wall_jumping['active']:
            return self.last_wall_direction
        elif self.dashing['active']:
            return self.dashing['dash_direction']
        else:
            return self.direction.x

    @property
    def vertical_movement_direction(self):
        return 0 if self.dashing['active'] else self.direction.y

    @property
    def jump_type(self):
        return 'wall_jump' if self.can_wall_jump else 'normal_jump'

    @property
    def can_start_coyote_time(self):
        return (self.was_on_ground and not self.on_ground) and not self.coyote_time['active'] and not self.jumped_this_frame

    @property
    def can_start_wall_coyote_time(self):
        return (self.was_on_wall and not self.on_wall) and not self.on_ground and not self.wall_coyote_time['active'] and not self.jumped_this_frame

    @property
    def moving(self):
        return self.direction.x != 0

    @property
    def can_normal_jump(self):
        return self.jump_count > 0

    @property
    def can_wall_jump(self):
        return ((self.on_wall or self.wall_coyote_time['active']) and not self.on_ground and not self.wall_jumping['active']) and PLAYER_ABILITIES['climb']['unlocked']

#---------------------------------
# State related methods
#---------------------------------

    def start_coyote_time(self):
        self.coyote_time['active'] = True
        self.coyote_time['current_duration'] = 0

    def end_coyote_time(self, expired=False):
        self.coyote_time['active'] = False
        self.coyote_time['current_duration'] = 0.0
        if expired:
            self.jump_count -= 1

    def update_coyote_time(self,dt):
        if self.can_start_coyote_time:
            self.start_coyote_time()
        if not self.coyote_time['active']:
            return
        if self.coyote_time['current_duration'] >= self.coyote_time['max_duration']:
            self.end_coyote_time(expired=True)
            return
        self.coyote_time['current_duration'] += dt

    def start_wall_coyote_time(self):
        self.wall_coyote_time['active'] = True
        self.wall_coyote_time['current_duration'] = 0.0

    def end_wall_coyote_time(self, expired=False):
        self.wall_coyote_time['active'] = False
        self.wall_coyote_time['current_duration'] = 0.0
        if expired:
            self.jump_count -= 1

    def update_wall_coyote_time(self, dt):
        if self.can_start_wall_coyote_time:
            self.start_wall_coyote_time()
        if not self.wall_coyote_time['active']:
            return
        if self.wall_coyote_time['current_duration'] >= self.wall_coyote_time['max_duration']:
            self.end_wall_coyote_time(expired=True)
            return
        self.wall_coyote_time['current_duration'] += dt

    def end_wall_jump(self):
        self.wall_jumping['active'] = False
        self.wall_jumping['current_duration'] = 0

    def update_wall_jump(self,dt):
        if not self.wall_jumping['active']:
            return
        if self.on_ground or self.on_wall:
            self.end_wall_jump()
            return
        if self.wall_jumping['current_duration'] >= self.wall_jumping['max_duration']:
            self.end_wall_jump()
            return
        self.wall_jumping['current_duration'] += dt

    def end_dash(self):
        self.dashing['active'] = False
        self.dashing['current_duration'] = 0

    def end_dash_cooldown(self):
        self.dash_cooldown['active'] = False
        self.dash_cooldown['current_duration'] = 0

    def update_dash_cooldown(self,dt):
        if self.dash_cooldown['current_duration'] >= self.dash_cooldown['max_duration']:
            self.end_dash_cooldown()
            return
        self.dash_cooldown['current_duration'] += dt

    def update_dash(self,dt):
        if self.dash_cooldown['active']:
            self.update_dash_cooldown(dt)
            pass
        if not self.dashing['active']:
            return
        if self.dashing['current_duration'] >= self.dashing['max_duration']:
            self.end_dash()
            return
        self.dashing['current_duration'] += dt

#---------------------------------
# Comand methods
#---------------------------------

    def walk(self,direction):
        if direction == 'left':
            self.direction.x = -1
        if direction == 'right':
            self.direction.x = 1

    def dash(self):
        if not PLAYER_ABILITIES['dash']['unlocked']:
            return
        if self.direction.x == 0:
            return
        if not self.dash_cooldown['active']:
            random.choice(SOUND_LIBRARY['dash']).play()
            self.dashing['active'] = True
            self.dash_cooldown['active'] = True
            self.dashing['dash_direction'] = self.direction.x * 2

    def invert_gravity(self):
        if PLAYER_ABILITIES['invert']['unlocked']:
            random.choice(SOUND_LIBRARY['inverse']).play()
            self.gravity_inverted = not self.gravity_inverted

    def jumped(self):
        random.choice(SOUND_LIBRARY['jump']).play()
        self.direction.y = -1 if not self.gravity_inverted else 1    
        self.jump_count -= 1
        self.vel.y = 0 
        self.get_off_ground()
        self.get_off_wall()
        self.end_coyote_time()  
        self.end_wall_coyote_time() 
        self.jumped_this_frame = True

    def jump(self): 
        if self.jump_type == 'normal_jump' and self.can_normal_jump:
            self.normal_jump()
            return
        if self.jump_type == 'wall_jump' and self.can_wall_jump:
            self.wall_jump()
            return

    def normal_jump(self):
        self.jumped()

    def wall_jump(self):
        self.jumped()
        self.wall_jumping['active'] = True

    def freeze(self):
        self.frozen = True

    def die(self):
        if GODMODE:
            return
        SOUND_LIBRARY['hit'].play()
        self.pos = self.respawn_pos().copy()
        self.rect.topleft = self.pos
        self.prev_pos = self.pos.copy()
        self.vel.y = 0
        self.gravity_inverted = False
        self.died = True

#---------------------------------
# Physics related methods
#---------------------------------

    def get_on_wall(self):
        super().get_on_wall()
        if PLAYER_ABILITIES['climb']['unlocked']:
            self.jump_count = self.max_jumps
            if self.collisions['right']:
                self.last_wall_direction = -1
            elif self.collisions['left']:
                self.last_wall_direction = 1
        self.end_dash_cooldown() 
    
    def get_on_ground(self):
        super().get_on_ground()
        self.jump_count = self.max_jumps
        self.end_dash_cooldown()

    def calculate_velocity(self):
        self.vel.x += self.horizontal_movement_direction * self.speed
        self.vel.y += self.vertical_movement_direction * self.jump_vel

    def resolve_gravity(self):
        gravity = GRAVITY
        max_wall_gravity = self.wall_slide_vel
        max_gravity = self.terminal_fall_vel
        if self.gravity_inverted:
            gravity = -GRAVITY
            max_wall_gravity = -max_wall_gravity
            max_gravity = -max_gravity
        if self.on_wall and PLAYER_ABILITIES['climb']['unlocked']:
            self.vel.y += gravity
            if self.gravity_inverted:
                self.vel.y = max(max_wall_gravity, self.vel.y)
            else:
                self.vel.y = min(max_wall_gravity, self.vel.y)
            return
        if self.dashing['active']:
            self.vel.y = 0
            return
        if not self.on_ground:
            self.vel.y += gravity
            self.vel.y = min(self.terminal_fall_vel, self.vel.y)
        else:
            self.vel.y = 0

    def check_coyote_states(self):
        if self.can_start_coyote_time:
            self.start_coyote_time()
        if self.can_start_wall_coyote_time:
            self.start_wall_coyote_time()

    def resolve_collisions(self):
        if self.gravity_inverted:
            self.collisions['top'], self.collisions['bottom'] = self.collisions['bottom'], self.collisions['top']
        super().resolve_collisions()
        self.check_coyote_states()
        self.jumped_this_frame = False 
        self.collisions = {'left' : False, 'right' : False, 'top' : False, 'bottom' : False}

#---------------------------------
# Render related methods
#---------------------------------

    def animate(self, dt):
        if not self.moving or not self.on_ground:
            if self.can_wall_jump or (self.wall_coyote_time['active'] and PLAYER_ABILITIES['climb']['unlocked']):
                self.animating['current_frame'] = 3
                return
            self.animating['current_frame'] = 0
            return
        
        if self.animating['current_duration'] >= self.animating['max_duration']:
            self.animating['current_frame'] += 1
            self.animating['current_frame'] = self.animating['current_frame'] % (len(self.images)-1)
            self.animating['current_duration'] = 0
            return
        self.animating['current_duration'] += dt

    def flip_sprite(self):
        direction = self.direction.x
        if PLAYER_ABILITIES['climb']['unlocked']:
            if self.wall_jumping['active']:
                direction = self.last_wall_direction
            elif self.wall_coyote_time['active']:
                direction = -self.last_wall_direction
        if direction > 0:
            if not self.horizontal_flip[0]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, True, False)
                self.horizontal_flip[0:len(self.horizontal_flip)] = True,False
        elif direction < 0:
            if not self.horizontal_flip[1]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, True, False)
                self.horizontal_flip[0:len(self.horizontal_flip)] = False,True

        if not self.gravity_inverted:
            if not self.vertical_flip[0]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, False, True)
                self.vertical_flip[0:len(self.vertical_flip)] = True,False
        else:
            if not self.vertical_flip[1]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, False, True)
                self.vertical_flip[0:len(self.vertical_flip)] = False,True
        self.image = self.images[self.animating['current_frame']] 

    def fixed_update(self):
        self.update_coyote_time(1/FIXED_TPS)
        self.update_wall_jump(1/FIXED_TPS)
        self.update_wall_coyote_time(1/FIXED_TPS)
        self.update_dash(1/FIXED_TPS)

    def update(self,dt):
        self.animate(dt)
        self.flip_sprite()

    def draw(self, surf, offset,alpha=1.0):
        render_x = self.prev_pos.x + (self.pos.x - self.prev_pos.x) * alpha
        render_y = self.prev_pos.y + (self.pos.y - self.prev_pos.y) * alpha

        draw_rect = self.rect.copy()
        draw_rect.topleft = (round(render_x), round(render_y))
        draw_rect = draw_rect.move(-offset.x, -offset.y)
        surf.blit(self.image, draw_rect)