import pygame
from ..globals import *
from .invisible_object import InvisibleObject

class Trigger(InvisibleObject):
    def __init__(self, x, y, width, height,show_layer,layer):
        super().__init__(x, y, width, height)
        self.show_layer = show_layer
        self.layer = layer
        self.activated = False

    def trigger(self):
        if not self.activated:
            self.show_layer(self.layer)
            self.activated = True