from .tile import Tile


class Flag(Tile):
    def __init__(self, pos, images,set_active):
        super().__init__(pos, images)
        self.set_active = set_active

    def trigger(self):
        self.set_active(self)

    def draw(self,surf,offset,alpha):
        draw_rect = self.rect.move(-offset.x,-offset.y)
        surf.blit(self.image,draw_rect)