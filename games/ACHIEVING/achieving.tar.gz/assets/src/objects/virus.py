import pygame
from .kinematic_object import KinematicObject
from ..globals import *


class Virus(KinematicObject):
    def __init__(self, pos, images,direction):
        super().__init__(pos, images)
        self.direction = direction

    def get_on_wall(self):
        self.direction.x = -self.direction.x
        return super().get_on_wall()

    def calculate_velocity(self):
        return super().calculate_velocity()

    def resolve_gravity(self):
        pass

    def resolve_collisions(self):
        self.vel.y = 0
        if self.collisions['top'] or self.collisions['bottom']:
            self.direction.y = -self.direction.y
        return super().resolve_collisions()

    def update(self, dt):
        return super().update(dt)

    def fixed_update(self):
        pass

    def draw(self, surf, offset,alpha=1.0):
        render_x = self.prev_pos.x + (self.pos.x - self.prev_pos.x) * alpha
        render_y = self.prev_pos.y + (self.pos.y - self.prev_pos.y) * alpha

        draw_rect = self.rect.copy()
        draw_rect.topleft = (round(render_x), round(render_y))
        draw_rect = draw_rect.move(-offset.x, -offset.y)
        surf.blit(self.images[0], draw_rect)
