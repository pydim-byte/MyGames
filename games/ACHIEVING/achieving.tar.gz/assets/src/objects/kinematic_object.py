import pygame
from .tile import Tile
from ..globals import *

class KinematicObject(Tile):
    def __init__(self, pos, images):
        super().__init__(pos, images)
        self.pos = pos
        self.prev_pos = self.pos.copy()
        self.direction = pygame.Vector2(0,0)

        self.vel = pygame.Vector2(0,0)
        self.speed = KINEMATIC_OBJECTS_STATS[type(self).__name__.lower()]['speed']
        self.terminal_fall_vel = KINEMATIC_OBJECTS_STATS[type(self).__name__.lower()]['terminal_fall_vel']

        self.collisions = {'left' : False, 'right' : False, 'top' : False, 'bottom' : False}
        self.on_ground = False
        self.was_on_ground = False
        self.on_wall = False
        self.was_on_wall = False

    def reset_direction(self):
        self.direction.xy = 0,0

    def get_on_wall(self):
        self.on_wall = True

    def get_off_wall(self):
        self.on_wall = False
    
    def get_on_ground(self):
        self.on_ground = True

    def get_off_ground(self):
        self.on_ground = False 

    def calculate_velocity(self):
        self.vel.x += self.direction.x * self.speed
        self.vel.y += self.direction.y * self.speed

    def move_horizontaly(self):
        self.pos.x += self.vel.x
        self.rect.x = self.pos.x

    def move_verticaly(self):
        self.pos.y += self.vel.y
        self.rect.y = self.pos.y

    def resolve_ground_state(self):
        self.was_on_ground = self.on_ground
        self.on_ground = False
        if self.collisions['bottom']:
            self.get_on_ground()
        if self.collisions['top']:
            self.vel.y = 0
        if not self.on_ground and self.was_on_ground:
            self.get_off_ground()

    def resolve_wall_state(self):
        self.was_on_wall = self.on_wall
        self.on_wall = False
        if self.collisions['left'] or self.collisions['right']:
            self.get_on_wall()
        if not self.on_wall and self.was_on_wall:
            self.get_off_wall()

    def resolve_gravity(self):
        if not self.on_ground:
            self.vel.y += GRAVITY
            self.vel.y = min(self.terminal_fall_vel, self.vel.y)
        else:
            self.vel.y = 0

    def resolve_collisions(self):
        self.vel.x = 0
        self.resolve_ground_state()
        self.resolve_wall_state()
        self.resolve_gravity()
        self.collisions = {'left' : False, 'right' : False, 'top' : False, 'bottom' : False}
