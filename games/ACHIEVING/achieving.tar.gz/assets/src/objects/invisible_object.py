import pygame
from ..globals import *

class InvisibleObject():
    def __init__(self,x,y,width,height):
        self.type = type(self).__name__.lower()
        self.rect = pygame.Rect(x,y,width,height)

    @property
    def is_solid(self):
        return self.type in SOLID_OBJETS

    def alive(self):
        return True