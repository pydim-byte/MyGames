import pygame
from .kinematic_object import KinematicObject
from ..globals import *


class InBoss(KinematicObject):
    def __init__(self, pos, images,target):
        super().__init__(pos, images)
        self.target = target

        self.max_jumps = 1
        self.jump_count = self.max_jumps
        self.jump_vel = 13

        self.target_reached = False
        self.waiting = True
        self.horizontal_flip = [True,False]
        self.animating = {'active' : True, 'current_duration' : 0.0, 'max_duration' : 0.1, 'current_frame' : 0}

    @property
    def moving(self):
        return self.direction.x != 0

    @property
    def can_jump(self):
        return self.jump_count > 0

    def get_on_ground(self):
        self.jump_count = 1
        return super().get_on_ground()

    def jump(self):
        self.direction.y = -1 
        self.jump_count -= 1
        self.vel.y = 0 

    def follow_player(self,player_pos):
        if not self.target_reached:
            return
        
        dist_to_player = self.pos.x - player_pos.x
        blind_spot = 4

        if dist_to_player - blind_spot > 0:
            self.direction.x = -1
        elif dist_to_player + blind_spot < 0:
            self.direction.x = 1
        else:
            self.direction.x = 0

        if self.pos.y >= player_pos.y - 8:
            if self.can_jump:
                self.jump()

    def die(self):
        self.kill()

    def calculate_velocity(self):
        if self.waiting:
            return
        
        self.vel.x += self.direction.x * self.speed
        if self.target_reached:
            self.vel.y += self.direction.y * self.jump_vel
        else:
            self.vel.y = 1 * self.speed

        self.direction.y = 0

    def resolve_gravity(self):
        if not self.target_reached:
            return
        return super().resolve_gravity()
    
    def fixed_update(self):
        if self.waiting:
            return
        if self.rect.y >= self.target:
            self.target_reached = True

    def animate(self, dt):
        if not self.moving or not self.on_ground:
            self.animating['current_frame'] = 0
            return
        if self.animating['current_duration'] >= self.animating['max_duration']:
            self.animating['current_frame'] += 1
            self.animating['current_frame'] = self.animating['current_frame'] % (len(self.images))
            self.animating['current_duration'] = 0
            return
        self.animating['current_duration'] += dt

    def flip_sprite(self):
        direction = self.direction.x
        
        if direction > 0:
            if not self.horizontal_flip[0]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, True, False)
                self.horizontal_flip[0:len(self.horizontal_flip)] = True,False
        elif direction < 0:
            if not self.horizontal_flip[1]:
                for i, img in enumerate(self.images):
                    self.images[i] = pygame.transform.flip(img, True, False)
                self.horizontal_flip[0:len(self.horizontal_flip)] = False,True

        self.image = self.images[self.animating['current_frame']] 

    def update(self,dt):
        if self.waiting:
            return
        self.animate(dt)
        self.flip_sprite()

    def draw(self, surf, offset,alpha=1.0):
        render_x = self.prev_pos.x + (self.pos.x - self.prev_pos.x) * alpha
        render_y = self.prev_pos.y + (self.pos.y - self.prev_pos.y) * alpha

        draw_rect = self.rect.copy()
        draw_rect.topleft = (round(render_x), round(render_y))
        draw_rect = draw_rect.move(-offset.x, -offset.y)
        surf.blit(self.image, draw_rect)
