import pygame
from ..globals import *

class Tile(pygame.sprite.Sprite):
    def __init__(self,pos,images):
        super().__init__()
        self.type = type(self).__name__.lower()
        self.pos = pos
        self.images = images
        self.image = self.images[0]
        self.rect = self.image.get_rect(topleft=pos)

    @property
    def is_solid(self):
        return self.type in SOLID_OBJETS

    def update(self,dt):
        pass

    def draw(self,surf,offset,alpha):
        draw_rect = self.rect.move(-offset.x,-offset.y)
        surf.blit(self.image,draw_rect)