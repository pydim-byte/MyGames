from .tile import Tile


class Error(Tile):
    def __init__(self, pos, images):
        super().__init__(pos, images)

    def draw(self, surf, offset, alpha):
        return super().draw(surf, offset, alpha)