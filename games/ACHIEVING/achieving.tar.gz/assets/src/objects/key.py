from .tile import Tile


class Key(Tile):
    def __init__(self, pos, images,key_id,unlock):
        super().__init__(pos, images)
        self.key_id = key_id
        self.unlock = unlock

    def trigger(self):
        self.unlock(self.key_id)
        self.kill()

    def draw(self, surf, offset, alpha):
        return super().draw(surf, offset, alpha)