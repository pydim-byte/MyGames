import pygame
from ..globals import *
from .invisible_object import InvisibleObject

class Spike(InvisibleObject):
    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height)