from .tile import Tile


class Lock(Tile):
    def __init__(self, pos, images,lock_id):
        super().__init__(pos, images)
        self.lock_id = lock_id

    def draw(self, surf, offset, alpha):
        return super().draw(surf, offset, alpha)