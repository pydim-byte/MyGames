import pygame
from ..globals import *


class State:
    def __init__(self):
        self.done = False
        self.quit = False
        self.next_state = None
        self.use_transition = True

    def handle_inputs(self,inputs):
        pass

    def fixed_update(self):
        pass
    
    def update(self,dt):
        pass

    def draw(self,screen,offset,alpha):
        pass