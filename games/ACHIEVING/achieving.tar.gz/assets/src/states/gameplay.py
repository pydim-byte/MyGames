from .state import State
import pygame, os
from src.globals import *
from src.camera import Camera
from src.tilemap import Tilemap
from src.physics_manager import PhysicsManager
from src.colision_manager import ColisionManger
from src.player_controller import PlayerController
from src.boss_fight_manager import BossFightManager

class Gameplay(State):
    def __init__(self):
        super().__init__()
        self.next_state = 'GAMEPLAY'
        self.camera = Camera()
        self.tilemap = Tilemap(CURRENT_LEVEL)

        self.kinematic_objs = self.tilemap.kinematic_sprites
        self.static_objs = self.tilemap.static_sprites

        self.physics_manager = PhysicsManager(self.kinematic_objs,self.static_objs)
        self.colision_manager = ColisionManger()
        self.boss_fight_manager = BossFightManager(self.tilemap.bosses,self.tilemap.player.sprite)

        self.player_controller = PlayerController(self.tilemap.player.sprite)
        self.offset = self.camera.get_offset(self.tilemap.player.sprite)

        SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
        jump_hollow_path = os.path.join(SCRIPT_DIR, "../../assets/images/ui_jump_orb/hollow.png")
        jump_filled_path = os.path.join(SCRIPT_DIR, "../../assets/images/ui_jump_orb/filled.png")
        dash_hollow_path = os.path.join(SCRIPT_DIR, "../../assets/images/ui_dash_orb/hollow.png")
        dash_filled_path = os.path.join(SCRIPT_DIR, "../../assets/images/ui_dash_orb/filled.png")

        self.jump_ui_hollow = pygame.image.load(jump_hollow_path).convert_alpha()
        self.jump_ui_filled = pygame.image.load(jump_filled_path).convert_alpha()
        self.dash_ui_hollow = pygame.image.load(dash_hollow_path).convert_alpha()
        self.dash_ui_filled = pygame.image.load(dash_filled_path).convert_alpha()

    def handle_inputs(self,inputs):
        global CURRENT_LEVEL
        global LEVEL_COMPLETION_UNLOCK
        global LEVEL_COUNTER
        self.player_controller.handle_inputs(inputs)
        if inputs['enter']:
            if CURRENT_LEVEL != MAX_LEVEL:
                if not self.tilemap.final_message_trigger.activated:
                    return
                if CURRENT_LEVEL < 4:
                    LEVEL_COMPLETION_UNLOCK[CURRENT_LEVEL]()
                CURRENT_LEVEL += 1
                LEVEL_COUNTER['levels_completed'] += 1
                SOUND_LIBRARY['blip'].play()
                self.done = True

    def fixed_update(self):
        global CURRENT_LEVEL
        global LEVEL_COUNTER
        global VICTORY_ACHIVED

        for obj in self.kinematic_objs:
            obj.prev_pos = obj.pos.copy()
        for sprite in self.kinematic_objs:
            sprite.fixed_update()
        colision_events = self.physics_manager.fixed_update()
        self.colision_manager.handle_events(colision_events)

        if CURRENT_LEVEL == MAX_LEVEL:
            if self.tilemap.player.sprite.died:
                self.use_transition = False
                self.done = True

        if self.boss_fight_manager.all_defeated and CURRENT_LEVEL == MAX_LEVEL:
                    win_game()
                    CURRENT_LEVEL = 1
                    LEVEL_COUNTER['levels_completed'] = 1
                    self.next_state = 'MAINMENU'
                    self.done = True


    def update(self,dt):
        if CURRENT_LEVEL == MAX_LEVEL:
            self.boss_fight_manager.update(dt)

        if self.tilemap.player.sprite.rect.top > SCREEN_HEIGHT:
            self.tilemap.player.sprite.die()

        for flag in self.tilemap.flags:
            if flag in self.tilemap.active_flag:
                flag.image = flag.images[1]
            else:
                flag.image = flag.images[0]
        for sprite in self.tilemap.all_sprites:
            sprite.update(dt)
        self.offset = self.camera.get_offset(self.tilemap.player.sprite)

    def draw(self,screen,alpha):
        for sprite in self.tilemap.all_sprites:
            sprite.draw(screen,self.offset,alpha)

        if self.tilemap.player.sprite.jump_count:
            for i in range(self.tilemap.player.sprite.jump_count):
                screen.blit(self.jump_ui_filled,(32*i,0))

        if PLAYER_ABILITIES['dash']['unlocked']:
            if not self.tilemap.player.sprite.dash_cooldown['active']:
                screen.blit(self.dash_ui_filled,(608,0))