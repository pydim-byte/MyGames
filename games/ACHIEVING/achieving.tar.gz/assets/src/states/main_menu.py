import pygame, os
from .state import State
from src.globals import *
from src.camera import Camera
from src.tilemap import Tilemap
from src.physics_manager import PhysicsManager
from src.colision_manager import ColisionManger
from src.player_controller import PlayerController
from src.boss_fight_manager import BossFightManager

class MainMenu(State):
    def __init__(self):
        super().__init__()
        self.next_state = 'GAMEPLAY'
        self.use_transition = True

        SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
        menu_image_path = os.path.join(SCRIPT_DIR, "../../assets/images/main_menu/menu_screen.png")
        pointer_image_path = os.path.join(SCRIPT_DIR, "../../assets/images/main_menu/pointer.png")
        victory_screen_path = os.path.join(SCRIPT_DIR, "../../assets/images/main_menu/victory_screen.png")
        self.menu_screen = pygame.image.load(menu_image_path).convert_alpha()
        self.victory_screen = pygame.image.load(victory_screen_path).convert_alpha()
        self.pointer = pygame.image.load(pointer_image_path).convert_alpha()
        self.pointer_positions = [(180,208),(180,276)]
        self.pointer_index = 0

    def handle_inputs(self,inputs):
        if inputs['up']:
            self.pointer_index -= 1
        if inputs['down']:
            self.pointer_index += 1
        self.set_pointer()
        if inputs['space']:
            if self.pointer_index == 0:
                self.done = True
            if self.pointer_index == len(self.pointer_positions)-1:
                quit_event = pygame.event.Event(pygame.QUIT)
                pygame.event.post(quit_event)

    def set_pointer(self):
        if self.pointer_index < 0:
            self.pointer_index = len(self.pointer_positions)-1

        if self.pointer_index > len(self.pointer_positions)-1:
            self.pointer_index = 0

    def fixed_update(self):
        pass

    def update(self,dt):
        pass

    def draw(self,screen,alpha):
        if VICTORY_ACHIVED['times'] == 0:
            screen.blit(self.menu_screen,(0,0))
        else:
            screen.blit(self.victory_screen,(0,0))
        screen.blit(self.pointer,self.pointer_positions[self.pointer_index]) 