SCREEN_WIDTH, SCREEN_HEIGHT = 640,480
DISPLAY_WIDTH, DISPLAY_HEIGHT = 640,480
TILE_SIZE = 8
TILE_SCALE = 4
FPS = 60
FIXED_TPS = 60

GRAVITY = 1

SOUND_LIBRARY = {'jump' : [],
                 'hit' : None,
                 'pickup' : [],
                 'trigger' : None,
                 'blip' : None,
                 'dash' : [],
                 'inverse' : [],}

SOLID_OBJETS = ['platform', 'lock']
KINEMATIC_OBJECTS_STATS = {
    'player' : {
        'speed' : 4,
        'jump_vel' : 13,
        'terminal_fall_vel' : 12,
        'wall_slide_vel' : 1,
    },
    'virus' : {
        'speed' : 4,
        'terminal_fall_vel' : 0,
    },
    'aboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
    'cboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
    'hboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
    'iboss' : {
        'speed' : 2,
        'terminal_fall_vel' : 6,
    },
    'eboss' : {
        'speed' : 2,
        'terminal_fall_vel' : 12,
    },
    'vboss' : {
        'speed' : 2,
        'terminal_fall_vel' : 12,
    },
    'inboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
    'nboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
    'gboss' : {
        'speed' : 4,
        'terminal_fall_vel' : 12,
    },
}

GODMODE = False

if GODMODE:
    PLAYER_ABILITIES = {
        'jump' : {'count' : 1},
        'climb' : {'unlocked' : True},
        'dash' : {'unlocked' : True},
        'invert' : {'unlocked' : True},
    }
else:
    PLAYER_ABILITIES = {
        'jump' : {'count' : 1},
        'climb' : {'unlocked' : False},
        'dash' : {'unlocked' : False},
        'invert' : {'unlocked' : False},
    }

def unlock_climb():
    PLAYER_ABILITIES['climb']['unlocked'] = True

def unlock_dash():
    PLAYER_ABILITIES['dash']['unlocked'] = True

def unlock_invert():
    PLAYER_ABILITIES['invert']['unlocked'] = True

LEVEL_COMPLETION_UNLOCK = {
    1 : unlock_climb,
    2 : unlock_dash,
    3 : unlock_invert,
}

CURRENT_LEVEL = 1
MAX_LEVEL = 9
# hack to properly transition betwen music based on levles
LEVEL_COUNTER = {'levels_completed' : 1}

VICTORY_ACHIVED = {'times' : 0}

def win_game():
    VICTORY_ACHIVED['times'] += 1




