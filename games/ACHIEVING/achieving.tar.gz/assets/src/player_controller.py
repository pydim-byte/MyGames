import pygame

class PlayerController:
    def __init__(self,player):
        self.player = player
        self.direction = pygame.Vector2(0,0)

    def handle_inputs(self,inputs):
        self.player.reset_direction()
        if self.player.frozen:
            return
        if inputs['left']:
            self.player.walk('left')
        if inputs['right']:
            self.player.walk('right')
        if inputs['down']:
            self.player.invert_gravity()
        if inputs['space']:
            self.player.jump()
        if inputs['shift']:
            self.player.dash()
