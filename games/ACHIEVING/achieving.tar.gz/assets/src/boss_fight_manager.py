class BossFightManager:
    def __init__(self, bosses, player):
        self.bosses = bosses
        self.player = player
        self.all_defeated = False
        self.current_boss = None
        self.current_phase = 0
        self.boss_queue = ['aboss', 'cboss', 'hboss', 'iboss', 'eboss', 'vboss', 'inboss', 'nboss', 'gboss']
        self.final_phase_start = len(self.boss_queue) - 3
        self.active_bosses = []

    def chase(self):
        if self.current_phase >= self.final_phase_start:
            if all(not b.alive() for b in self.active_bosses):
                self.all_defeated = True
                return
            for boss in self.active_bosses:
                if boss.alive():
                    boss.follow_player(self.player.pos)
            return

        if not self.current_boss.alive():
            self.current_phase += 1

            # Transition into final phase
            if self.current_phase >= self.final_phase_start:
                for boss_type in self.boss_queue[self.final_phase_start:]:
                    for b in self.bosses:
                        if b.type == boss_type:
                            b.waiting = False
                            self.active_bosses.append(b)
                            break
                self.current_boss = None
                return

            # Normal single-boss advance
            boss_type = self.boss_queue[self.current_phase]
            for b in self.bosses:
                if b.type == boss_type:
                    self.current_boss = b
                    self.current_boss.waiting = False
                    break
            return

        self.current_boss.follow_player(self.player.pos)

    def update(self, dt):
        if self.current_boss is None and not self.active_bosses:
            boss_type = self.boss_queue[self.current_phase]
            for b in self.bosses:
                if b.type == boss_type:
                    self.current_boss = b
                    self.current_boss.waiting = False
                    break

        if self.current_boss or self.active_bosses:
            self.chase()