import sys,pygame, asyncio
from src.globals import *
from src.states.gameplay import Gameplay
from src.states.main_menu import MainMenu

STATES = {
    'GAMEPLAY' : Gameplay,
    'MAINMENU' : MainMenu,
}

START_STATE = 'MAINMENU'

class Game:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()

        self.curect_track_number = 0
        pygame.mixer.music.load('assets/audio/normal_paris.ogg')

        # SOUNDS
        global SOUND_LIBRARY
        self.jump_0 = pygame.mixer.Sound('assets/audio/jump/0.ogg')
        self.jump_1 = pygame.mixer.Sound('assets/audio/jump/1.ogg')
        self.jump_2 = pygame.mixer.Sound('assets/audio/jump/2.ogg')
        self.jumps_sounds = [self.jump_0,self.jump_1,self.jump_2]
        for j in self.jumps_sounds:
            j.set_volume(0.4)
        SOUND_LIBRARY['jump'].extend(self.jumps_sounds)

        self.hit = pygame.mixer.Sound('assets/audio/hit/0.ogg')
        self.hit.set_volume(1.0)
        SOUND_LIBRARY['hit'] = self.hit

        self.pickup_0 = pygame.mixer.Sound('assets/audio/pickup/0.ogg')
        self.pickup_1 = pygame.mixer.Sound('assets/audio/pickup/1.ogg')
        self.pickup_2 = pygame.mixer.Sound('assets/audio/pickup/2.ogg')
        self.pickup_sounds = [self.pickup_0,self.pickup_1,self.pickup_2]
        for p in self.pickup_sounds:
            p.set_volume(0.4)
        SOUND_LIBRARY['pickup'].extend(self.pickup_sounds)

        self.trigger = pygame.mixer.Sound('assets/audio/trigger/0.ogg')
        self.trigger.set_volume(0.8)
        SOUND_LIBRARY['trigger'] = self.trigger

        self.blip = pygame.mixer.Sound('assets/audio/blip/0.ogg')
        self.blip.set_volume(0.2)
        SOUND_LIBRARY['blip'] = self.blip

        self.dash_0 = pygame.mixer.Sound('assets/audio/dash/0.ogg')
        self.dash_1 = pygame.mixer.Sound('assets/audio/dash/1.ogg')
        self.dash_2 = pygame.mixer.Sound('assets/audio/dash/2.ogg')
        self.dash_sounds = [self.dash_0,self.dash_1,self.dash_2]
        for p in self.dash_sounds:
            p.set_volume(1.0)
        SOUND_LIBRARY['dash'].extend(self.dash_sounds)

        self.inverse_0 = pygame.mixer.Sound('assets/audio/inverse/0.ogg')
        self.inverse_1 = pygame.mixer.Sound('assets/audio/inverse/1.ogg')
        self.inverse_2 = pygame.mixer.Sound('assets/audio/inverse/2.ogg')
        self.inverse_sounds = [self.inverse_0,self.inverse_1,self.inverse_2]
        for p in self.inverse_sounds:
            p.set_volume(0.2)
        SOUND_LIBRARY['inverse'].extend(self.inverse_sounds)

        # MUSIC
        pygame.mixer.music.set_volume(0.1)
        pygame.mixer.music.play(-1)

        self.display = pygame.display.set_mode((DISPLAY_WIDTH,DISPLAY_HEIGHT))
        self.screen = pygame.Surface((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.clock = pygame.Clock()
        self.acumulated_time = 0
        self.inputs = {
            'left' : False, 'right' : False, 'up' : False, 'down' : False, 'space' : False, 'shift' : False, 'enter' : False
        }

        self.states = STATES
        self.state_name = START_STATE
        self.state = self.states[self.state_name]() 

        self.transition = False
        self.transition_alpha = 0       
        self.transition_speed = 180    
        self.old_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))

    def flip_state(self):
        wants_transition = self.state.use_transition 

        if wants_transition:
            self.old_surface.blit(self.screen, (0, 0))

        next_state = self.state.next_state
        self.state.done = False
        self.state_name = next_state
        self.state = self.states[self.state_name]()

        if wants_transition:
            self.transition = True
            self.transition_alpha = 255   

    def next_music_track(self):
        levels = LEVEL_COUNTER['levels_completed']

        # 1. RESET: If level is low but track number is high, user restarted.
        if levels < 8 and self.curect_track_number != 0:
            pygame.mixer.music.load('assets/audio/normal_paris.ogg')
            pygame.mixer.music.play(-1, fade_ms=2000)
            self.curect_track_number = 0

        # 2. STOP: Level 8 should be silent (fading out)
        elif levels == 8 and self.curect_track_number == 0:
            pygame.mixer.music.fadeout(500)
            # We set this to a temporary state so it doesn't call fadeout() every frame
            self.curect_track_number = 0.5 

        # 3. BOSS START: Level 9 starts the new track
        elif levels == 9 and self.curect_track_number == 0.5:
            pygame.mixer.music.load('assets/audio/virus_dublin.ogg')
            pygame.mixer.music.play(-1, fade_ms=500)
            self.curect_track_number = 1

        # 4. POST-BOSS: Level 1 goes back to normal
        elif levels == 1 and self.curect_track_number == 1:
            pygame.mixer.music.fadeout(2000)
            pygame.mixer.music.load('assets/audio/normal_paris.ogg')
            pygame.mixer.music.play(-1, fade_ms=2000)
            self.curect_track_number = 2

    def handle_events(self,event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.inputs['left'] = True
            if event.key == pygame.K_RIGHT:
                self.inputs['right'] = True
            if event.key == pygame.K_UP:
                self.inputs['up'] = True
            if event.key == pygame.K_DOWN:
                self.inputs['down'] = True
            if event.key == pygame.K_SPACE:
                self.inputs['space'] = True
            if event.key == pygame.K_LSHIFT:
                self.inputs['shift'] = True
            if event.key == pygame.K_RETURN:
                self.inputs['enter'] = True

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.inputs['left'] = False
            if event.key == pygame.K_RIGHT:
                self.inputs['right'] = False
            if event.key == pygame.K_DOWN:
                self.inputs['down'] = False
            if event.key == pygame.K_UP:
                self.inputs['up'] = False
            if event.key == pygame.K_SPACE:
                self.inputs['space'] = False
            if event.key == pygame.K_LSHIFT:
                self.inputs['shift'] = False
            if event.key == pygame.K_RETURN:
                self.inputs['enter'] = False

    def handle_inputs(self,inputs):
        if not self.transition:
            self.state.handle_inputs(inputs)
        # reset space until pressed again
        self.inputs['up'] = False
        self.inputs['down'] = False
        self.inputs['space'] = False
        self.inputs['shift'] = False

    def fixed_update(self):
        if not self.transition:
            self.state.fixed_update()

    def update(self,dt):
        if self.state.quit:
            self.done = True
            return
        
        if self.state.done and not self.transition:
            self.flip_state() 

        if self.transition:
            self.transition_alpha -= self.transition_speed * dt
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition = False

        if not self.transition:
            self.state.update(dt)
        
    def draw(self,alpha):
        self.display.fill('black')
        self.screen.fill('black')
        self.state.draw(self.screen,alpha)

        if self.transition:
            self.old_surface.set_alpha(int(self.transition_alpha))
            self.screen.blit(self.old_surface, (0, 0))

        self.display.blit(self.screen,(0,0))
        pygame.display.flip()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                self.handle_events(event)

            fixed_tick = 1/FIXED_TPS
            dt = self.clock.tick(FPS) / 1000
            dt = min(0.1,dt)
            self.acumulated_time += dt

            while self.acumulated_time >= fixed_tick:
                self.handle_inputs(self.inputs)
                self.fixed_update()
                self.acumulated_time -= fixed_tick

            alpha = self.acumulated_time / fixed_tick

            self.update(dt)
            self.draw(alpha)

            self.next_music_track()

            await asyncio.sleep(0)


game = Game()
asyncio.run(game.run())
