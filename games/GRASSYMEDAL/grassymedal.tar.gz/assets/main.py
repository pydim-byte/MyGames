# /// script
# dependencies = [
#   "pygame_gui",
#   "python-i18n",
# ]
# ///
import pygame,os,sys,asyncio
import pygame_gui
from pytmx import load_pygame
from enum import Enum, auto
 
TILEMAP_LOCATION = os.path.join('assets','tilemap','rpg_map.tmx')
SCREEN_WIDTH, SCREEN_HEIGHT = 256, 144
DISPLAY_WIDTH, DISPLAY_HEIGHT = 1024, 576
GRID_W = 16
GRID_H = 9
FPS = 60


class Unit:
    def __init__(self,x,y,type,team,hp,move_range,atack_range,atack_damage,facing,image):
        self.x = x
        self.y = y
        self.type = type
        self.team = team
        self.hp = hp
        self.atack_range = atack_range
        self.atack_damage = atack_damage
        self.move_range = int(move_range)
        self.facing = facing
        self.image = image
        self.has_moved = False


class GameTurn(Enum):
    PLAYER_TURN = auto()
    ENEMY_TURN = auto()


class GameState(Enum):
    MAP_IDLE = auto()        
    UNIT_SELECTED = auto()   
    ACTION_MENU = auto()     
    ENEMY_PHASE = auto()  
    VICTORY_PHASE = auto() 


class Tilemap:
    def __init__(self):
        self.level = load_pygame(TILEMAP_LOCATION)
        self.unit_grid = [[None for _ in range(GRID_W)] for _ in range(GRID_H)]
        self.walkable = [[True for _ in range(GRID_W)] for _ in range(GRID_H)]
        self.find_blocked()

        self.units = []
        self.get_units()

    def find_blocked(self):
        for obj in self.level.objects:
            if obj.type != 'blocking':
                continue
            gx = int(obj.x // 16)
            gy = int(obj.y // 16)
            self.walkable[gy][gx] = False

    def get_units(self):
        for obj in self.level.objects:
            if obj.type != 'unit':
                continue
            x = int(obj.x//16)
            y = int(obj.y//16)
            type = obj.properties['unit_type']
            team = obj.properties['team']

            hp = obj.properties['hp'] 
            move_range = obj.properties['move_range']
            atack_range = obj.properties['atack_range']
            atack_damage = obj.properties['atack_damage']

            facing = obj.properties['facing']
            image = obj.image
            unit = Unit(x,y,type,team,hp,move_range,atack_range,atack_damage,facing,image)
            self.units.append(unit)
            self.unit_grid[y][x] = unit

    def get_move_tiles(self,start_x,start_y,max_range):
        visited = set()
        reachable = set()
        frontier = [(start_x,start_y,0)]

        while frontier:
            x,y,dist = frontier.pop(0)

            if dist > max_range:
                continue
            if (x,y) in visited:
                continue

            visited.add((x,y))
            reachable.add((x,y))

            for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                nx,ny = x + dx, y + dy
                if not (0 <= nx < GRID_W) or not (0 <= ny < GRID_H):
                    continue
                if not self.walkable[ny][nx] or self.unit_grid[ny][nx] is not None:
                    continue
                frontier.append((nx, ny, dist + 1))

        return reachable
    

    def get_attack_tiles(self, unit):
        attack_tiles = set()
        for dx in range(-unit.atack_range, unit.atack_range + 1):
            for dy in range(-unit.atack_range, unit.atack_range + 1):
                x = unit.x + dx
                y = unit.y + dy
                if 0 <= x < GRID_W and 0 <= y < GRID_H:
                    target = self.unit_grid[y][x]
                    if target and target.team != unit.team:
                        attack_tiles.add((x, y))
        return attack_tiles

    def move_unit(self, unit, target_x, target_y, mark_moved=False):
        self.unit_grid[unit.y][unit.x] = None  
        unit.x, unit.y = target_x, target_y
        self.unit_grid[target_y][target_x] = unit  
        if mark_moved:
            unit.has_moved = True
        

    def draw(self,screen):
        for layer in self.level.visible_layers:
            if not hasattr(layer,'tiles'):
                continue
            for x,y,image in layer.tiles():
                screen.blit(image,(x*16,y*16))
        
        for unit in self.units:
            screen.blit(unit.image, (unit.x * 16, unit.y * 16))

        for unit in self.units:
            screen.blit(unit.image, (unit.x*16, unit.y*16))
            
            # Health bar
            hp_ratio = max(unit.hp, 0) / 5  # assuming max HP = 10, adjust as needed
            pygame.draw.rect(screen, (255,0,0), (unit.x*16+2, unit.y*16-2, 12, 2))  # background
            pygame.draw.rect(screen, (0,255,0), (unit.x*16+2, unit.y*16-2, int(12*hp_ratio), 2))  # green bar


class Cursor:
    def __init__(self):
        self.x = 0
        self.y = 0

    def move(self,dx,dy):
        self.x = max(0,min(GRID_W-1,self.x+dx))
        self.y = max(0,min(GRID_H-1,self.y+dy))

    def draw(self, screen):
        rect = pygame.Rect(self.x * 16, self.y * 16, 16, 16)
        pygame.draw.rect(screen, (255,255,0), rect, 1)



class Game:
    def __init__(self):
        pygame.init()
        self.clock = pygame.Clock()
        self.screen = pygame.Surface((SCREEN_WIDTH,SCREEN_HEIGHT))
        self.display = pygame.display.set_mode((DISPLAY_WIDTH,DISPLAY_HEIGHT))
        self.tilemap = Tilemap()
        self.cursor = Cursor()

        self.team_winner = None

        self.ui_manager = pygame_gui.UIManager((DISPLAY_WIDTH,DISPLAY_HEIGHT),theme_path='theme.json')
        self.player_label = pygame_gui.elements.UILabel(relative_rect=pygame.Rect((0*4+64,128*4),(96*3,16*4)),
                                                        text='PLAYER   TURN',
                                                        manager=self.ui_manager,
                                                        object_id="#player_turn_label")
        
        self.enemy_label = pygame_gui.elements.UILabel(relative_rect=pygame.Rect((160*4+96-64,128*4),(96*3,16*4)),
                                                text='ENEMY   TURN',
                                                manager=self.ui_manager,
                                                object_id="#enemy_turn_label")
        
        self.battle_resolution_label = pygame_gui.elements.UILabel(relative_rect=pygame.Rect((DISPLAY_WIDTH/2-450,DISPLAY_HEIGHT/2-270),(900,540)),
                                                text=f'{self.team_winner} WON!',
                                                manager=self.ui_manager,
                                                object_id="#battle_resolution_label")
        self.battle_resolution_label.hide()
        
        
        self.game_state = GameState.MAP_IDLE
        self.current_turn = GameTurn.PLAYER_TURN
        self.selected_unit = None

        self.enemy_turn_finished = False

        self.enemy_move_timer = 0
        self.enemy_move_delay = 0.2

        self.enemy_queue = []           # list of enemy units yet to act
        self.current_enemy = None       # enemy currently moving
        self.enemy_move_path = []       # path to move along (list of tiles)

    def reset_game(self):
        # Reload tilemap and units
        self.tilemap = Tilemap()

        # Reset turn state
        self.current_turn = GameTurn.PLAYER_TURN
        self.selected_unit = None
        self.game_state = GameState.MAP_IDLE
        self.enemy_queue = []
        self.current_enemy = None
        self.enemy_move_path = []
        self.enemy_move_timer = 0
        self.team_winner = None

        # Reset UI
        self.player_label.show()
        self.enemy_label.hide()
        self.battle_resolution_label.hide()

    def update(self, dt):
        if self.check_game_over():
            self.player_label.hide()
            self.enemy_label.hide()
            self.battle_resolution_label.show()
            return
        # --- Check if player turn should end ---
        if self.current_turn == GameTurn.PLAYER_TURN:
            if all(unit.has_moved for unit in self.tilemap.units if unit.team == 'player'):
                self.current_turn = GameTurn.ENEMY_TURN
                self.selected_unit = None
                self.game_state = GameState.MAP_IDLE
                for unit in self.tilemap.units:
                    if unit.team == 'enemy':
                        unit.has_moved = False

        # --- Enemy turn logic ---
        if self.current_turn == GameTurn.ENEMY_TURN:
            # Initialize enemy queue at start of enemy turn
            if not self.enemy_queue and not self.current_enemy:
                self.enemy_queue = [u for u in self.tilemap.units if u.team == 'enemy' and not u.has_moved]
                self.enemy_move_path = []

            # Pick next enemy if none currently acting
            if not self.current_enemy and self.enemy_queue:
                self.current_enemy = self.enemy_queue.pop(0)
                print(f"Enemy turn: Processing {self.current_enemy.type} at ({self.current_enemy.x}, {self.current_enemy.y}), {len(self.enemy_queue)} enemies remaining")

                # Find nearest player
                player_units = [u for u in self.tilemap.units if u.team == 'player']
                if not player_units:
                    # No player units left
                    self.current_enemy.has_moved = True
                    self.current_enemy = None
                    self.enemy_move_path = []
                else:
                    player = min(
                        player_units,
                        key=lambda p: abs(p.x - self.current_enemy.x) + abs(p.y - self.current_enemy.y)
                    )
                    # Compute reachable tiles
                    move_tiles = self.tilemap.get_move_tiles(
                        self.current_enemy.x,
                        self.current_enemy.y,
                        self.current_enemy.move_range
                    )
                    # Remove tiles occupied by other units
                    move_tiles = [t for t in move_tiles if self.tilemap.unit_grid[t[1]][t[0]] is None]

                    if move_tiles:
                        # Pick tile closest to player
                        best_tile = min(move_tiles, key=lambda t: abs(t[0] - player.x) + abs(t[1] - player.y))
                        # Compute path using BFS
                        self.enemy_move_path = self.compute_bfs_path(
                            self.current_enemy.x, self.current_enemy.y,
                            best_tile[0], best_tile[1]
                        )
                    else:
                        # Enemy cannot move - set empty path but still check for attacks
                        self.enemy_move_path = []

                self.enemy_move_timer = 0

            # --- Move along path one tile per frame ---
            if self.current_enemy and self.enemy_move_path:
                self.enemy_move_timer += dt
                if self.enemy_move_timer >= self.enemy_move_delay:
                    next_tile = self.enemy_move_path.pop(0)
                    # Only move if tile is free
                    if self.tilemap.unit_grid[next_tile[1]][next_tile[0]] is None:
                        self.tilemap.move_unit(self.current_enemy, next_tile[0], next_tile[1])
                    self.enemy_move_timer = 0

            # --- Attack if movement finished ---
            if self.current_enemy and not self.enemy_move_path:
                attack_tiles = self.tilemap.get_attack_tiles(self.current_enemy)
                for target in [u for u in self.tilemap.units if u.team == 'player']:
                    if (target.x, target.y) in attack_tiles:
                        self.attack_unit(self.current_enemy, target)

                # Mark enemy as done
                self.current_enemy.has_moved = True
                print(f"Enemy {self.current_enemy.type} finished turn")
                self.current_enemy = None

            # End enemy turn if all enemies acted
            if not self.enemy_queue and not self.current_enemy:
                print("All enemies finished, switching to player turn")
                self.current_turn = GameTurn.PLAYER_TURN
                for unit in self.tilemap.units:
                    if unit.team == 'player':
                        unit.has_moved = False

        if self.current_turn == GameTurn.PLAYER_TURN:
            self.player_label.show()
            self.enemy_label.hide()

        if self.game_state == GameState.MAP_IDLE:
            self.player_label.text = 'SELECT UNIT'
            self.player_label.rebuild()

        if self.game_state == GameState.UNIT_SELECTED:
            self.player_label.text = 'MOVE UNIT'
            self.player_label.rebuild()

        if self.game_state == GameState.ACTION_MENU:
            self.player_label.text = 'ATACK WITH UNIT'
            self.player_label.rebuild()

        if self.current_turn == GameTurn.ENEMY_TURN:
            self.player_label.hide()
            self.enemy_label.show()

        if self.game_state == GameState.VICTORY_PHASE:
            self.player_label.hide()
            self.enemy_label.hide()
            self.battle_resolution_label.show()


    def check_game_over(self):
        player_units = [u for u in self.tilemap.units if u.team == 'player']
        enemy_units = [u for u in self.tilemap.units if u.team == 'enemy']

        if not player_units:
            self.team_winner = "ENEMY"
            self.game_state = GameState.VICTORY_PHASE
            self.battle_resolution_label.set_text(f"{self.team_winner} WON! PRESS SPACE TO RESTART")
            self.battle_resolution_label.rebuild()
            return True

        if not enemy_units:
            self.team_winner = "PLAYER"
            self.game_state = GameState.VICTORY_PHASE
            self.battle_resolution_label.set_text(f"{self.team_winner} WON! PRESS SPACE TO RESTART")
            self.battle_resolution_label.rebuild()
            return True

        return False


    def select_unit(self):
        unit = self.tilemap.unit_grid[self.cursor.y][self.cursor.x]
        if unit and unit.team == 'player':
            self.selected_unit = unit
            if unit.has_moved:
                self.selected_unit = None
                return
            self.game_state = GameState.UNIT_SELECTED
            unit = self.selected_unit

    def attack_unit(self, attacker, target):
        target.hp -= attacker.atack_damage
        print(f"{attacker.type} attacked {target.type} for {attacker.atack_damage} damage!")
        if target.hp <= 0:
            print(f"{target.type} has been defeated!")
            self.tilemap.unit_grid[target.y][target.x] = None
            self.tilemap.units.remove(target)
        self.check_game_over()  # <-- add this


    def enemy_turn(self):
        for enemy in [u for u in self.tilemap.units if u.team == 'enemy' and not u.has_moved]:
            player_units = [u for u in self.tilemap.units if u.team == 'player']
            if player_units:
                # Move closer
                player = player_units[0]
                move_tiles = self.tilemap.get_move_tiles(enemy.x, enemy.y, enemy.move_range)
                best_tile = min(move_tiles, key=lambda t: abs(t[0]-player.x) + abs(t[1]-player.y))
                self.tilemap.move_unit(enemy, best_tile[0], best_tile[1])
                
                # Attack if any in range
                for target in player_units:
                    if (target.x, target.y) in self.tilemap.get_attack_tiles(enemy):
                        self.attack_unit(enemy, target)
                enemy.has_moved = True

    def compute_path(self, start_x, start_y, target_x, target_y):
        """Generate a simple straight-line path from start to target."""
        path = []
        x, y = start_x, start_y
        while (x, y) != (target_x, target_y):
            if x < target_x:
                x += 1
            elif x > target_x:
                x -= 1
            elif y < target_y:
                y += 1
            elif y > target_y:
                y -= 1
            path.append((x, y))
        return path

        # --- BFS Pathfinding for enemy movement ---
    def compute_bfs_path(self, start_x, start_y, target_x, target_y):
        from collections import deque

        visited = set()
        parent = {}
        queue = deque([(start_x, start_y)])
        visited.add((start_x, start_y))

        while queue:
            x, y = queue.popleft()
            if (x, y) == (target_x, target_y):
                # Reconstruct path
                path = []
                while (x, y) != (start_x, start_y):
                    path.append((x, y))
                    x, y = parent[(x, y)]
                path.reverse()
                return path

            for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < GRID_W and 0 <= ny < GRID_H:
                    if (nx, ny) not in visited and self.tilemap.walkable[ny][nx] and \
                    (self.tilemap.unit_grid[ny][nx] is None or (nx, ny) == (target_x, target_y)):
                        visited.add((nx, ny))
                        parent[(nx, ny)] = (x, y)
                        queue.append((nx, ny))
        # No path found
        return []

    def handle_inputs(self, inputs):
        if self.game_state == GameState.VICTORY_PHASE:
            if inputs[pygame.K_SPACE]:
                self.reset_game()
            
        # Move cursor anytime
        if inputs[pygame.K_RIGHT]:
            self.cursor.move(1,0)
        if inputs[pygame.K_LEFT]:
            self.cursor.move(-1,0)
        if inputs[pygame.K_DOWN]:
            self.cursor.move(0,1)
        if inputs[pygame.K_UP]:
            self.cursor.move(0,-1)

        # Selecting a unit
        if self.game_state == GameState.MAP_IDLE:
            if inputs[pygame.K_SPACE]:
                self.select_unit()

        # Moving a selected unit
        elif self.game_state == GameState.UNIT_SELECTED and self.selected_unit:
            move_tiles = self.tilemap.get_move_tiles(
                self.selected_unit.x,
                self.selected_unit.y,
                self.selected_unit.move_range
            )

            # Confirm move
            if inputs[pygame.K_SPACE]:
                if (self.cursor.x, self.cursor.y) in move_tiles:
                    self.tilemap.move_unit(self.selected_unit, self.cursor.x, self.cursor.y)
                    self.game_state = GameState.ACTION_MENU  # instead of MAP_IDLE

            # Cancel selection
            if inputs[pygame.K_ESCAPE]:
                self.selected_unit = None
                self.game_state = GameState.MAP_IDLE


        if self.game_state == GameState.ACTION_MENU and self.selected_unit:
            attack_tiles = self.tilemap.get_attack_tiles(self.selected_unit)

            # If no enemies are in range, auto-end action phase
            if not attack_tiles:
                self.selected_unit.has_moved = True
                self.selected_unit = None
                self.game_state = GameState.MAP_IDLE
                print("No enemies in range, turn ended.")
            else:
                target = self.tilemap.unit_grid[self.cursor.y][self.cursor.x]
                if inputs[pygame.K_SPACE] and target and target.team != self.selected_unit.team:
                    self.attack_unit(self.selected_unit, target)
                    self.selected_unit.has_moved = True
                    self.selected_unit = None
                    self.game_state = GameState.MAP_IDLE
                elif inputs[pygame.K_ESCAPE]:
                    self.selected_unit.has_moved = True
                    self.selected_unit = None
                    self.game_state = GameState.MAP_IDLE


    def draw(self):
        self.screen.fill("#00FF04")
        self.tilemap.draw(self.screen)

        # Only draw move tiles if unit is selected for moving
        if self.game_state == GameState.UNIT_SELECTED and self.selected_unit:
            move_tiles = self.tilemap.get_move_tiles(
                self.selected_unit.x,
                self.selected_unit.y,
                self.selected_unit.move_range
            )
            for x, y in move_tiles:
                pygame.draw.rect(self.screen, (0,0,255), ((x*16+1, y*16+1), (14,14)), 1)

        # Only draw attack tiles if we're in action menu
        if self.game_state == GameState.ACTION_MENU and self.selected_unit:
            attack_tiles = self.tilemap.get_attack_tiles(self.selected_unit)
            for x, y in attack_tiles:
                pygame.draw.rect(self.screen, (255,0,0), ((x*16+1, y*16+1), (14,14)), 1)

        if self.current_turn == GameTurn.PLAYER_TURN:
            for unit in self.tilemap.units:
                if unit.team != 'player':
                    continue
                if unit.has_moved:
                    s = pygame.Surface((16,16), pygame.SRCALPHA)  # Alpha surface
                    s.fill((0,0,0,50))  # Semi-transparent black
                    self.screen.blit(s, (unit.x*16, unit.y*16))

        self.cursor.draw(self.screen)
        self.display.blit(pygame.transform.scale(self.screen,self.display.get_rect().size),(0,0))
        self.ui_manager.draw_ui(self.display)
        pygame.display.flip()


    async def run(self):
        while True:
            just_pressed = set()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    just_pressed.add(event.key)

                self.ui_manager.process_events(event)

            # Proxy object so inputs[K_x] syntax still works unchanged
            inputs = type('Keys', (), {'__getitem__': lambda self, k: k in just_pressed})()
            dt = self.clock.tick(FPS) / 1000

            self.handle_inputs(inputs)

            self.ui_manager.update(dt)
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)
            
game = Game()
asyncio.run(game.run())