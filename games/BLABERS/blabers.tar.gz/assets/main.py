# /// script
# dependencies = [
#   "pygame_gui",
#   "python-i18n",
# ]
# ///

import os
import sys
import asyncio
from collections import defaultdict

import pygame
import pygame_gui
import markovify


SCREEN_WIDTH, SCREEN_HEIGHT = 960, 540
FPS = 60
TARGET_WORDS = ["you", "and", "me"]


with open("dracula.txt", encoding="utf-8") as f:
    DRACULA = f.read()

with open("ulysses.txt", encoding="utf-8") as f:
    ULYSSES = f.read()

with open("sherlock.txt", encoding="utf-8") as f:
    SHERLOCK = f.read()


DRACULA_BLABER = markovify.Text(DRACULA)
ULYSSES_BLABER = markovify.Text(ULYSSES)
SHERLOCK_BLABER = markovify.Text(SHERLOCK)


def normalize_word(word: str) -> str:
    return word.lstrip("—_").lower().strip(".,!?;:\"'`()[]{}")


class EventBus:
    def __init__(self):
        self.listeners = defaultdict(list)

    def subscribe(self, event_type, handler):
        self.listeners[event_type].append(handler)

    def emit(self, event_type, **payload):
        for handler in self.listeners[event_type]:
            handler(**payload)


event_bus = EventBus()


class TextLinker:
    def __init__(self, target_words):
        self.target_words = set(target_words)
        self.found_words = set()

    def set_found_words(self, found_words):
        self.found_words = set(found_words)

    def is_target(self, word: str) -> bool:
        return normalize_word(word) in self.target_words

    def is_found(self, word: str) -> bool:
        return normalize_word(word) in self.found_words


class Blaber:
    def __init__(self, head_pos, head_size, text_pos, text_size, text_origin, ui_manager):
        self.head_pos = head_pos
        self.head_size = head_size
        self.text_pos = text_pos
        self.text_size = text_size
        self.text_origin = text_origin
        self.ui_manager = ui_manager

        self.skin_color = (255, 220, 200)
        self.eye_color = (0, 0, 0)
        self.blinking = False
        self.blink_time = 0
        self.blink_duration = 0.15

        self.text_linker = TextLinker(TARGET_WORDS)

        self.font = pygame.font.Font(None, 26)
        self.current_text = ""
        self.word_items = []
        self.text_surface = pygame.Surface(self.text_size, pygame.SRCALPHA)

        self.update_text_box()

    def make_new_text(self):
        text = self.text_origin.make_short_sentence(100)
        if not text:
            text = self.text_origin.make_sentence()
        if not text:
            text = ""
        return text

    def update_text_box(self):
        self.current_text = self.make_new_text()
        self.rebuild_text_layout()

    def set_found_words(self, words):
        self.text_linker.set_found_words(words)
        self.rebuild_text_layout()

    def rebuild_text_layout(self):
        self.word_items = []
        self.text_surface = pygame.Surface(self.text_size, pygame.SRCALPHA)
        self.text_surface.fill((245, 245, 245, 255))

        x = 0
        y = 0
        max_w, max_h = self.text_size
        line_h = self.font.get_linesize() + 2
        space_w = self.font.size(" ")[0]

        for token in self.current_text.split():
            key = normalize_word(token)
            is_target = key in self.text_linker.target_words
            is_found = key in self.text_linker.found_words

            if is_target and is_found:
                color = (33, 189, 0)
            elif is_target:
                color = (255, 41, 0)
            else:
                color = (20, 20, 20)

            surf = self.font.render(token, True, color)
            w, h = surf.get_size()

            if x + w > max_w:
                x = 0
                y += line_h

            if y + h > max_h:
                break

            rect = surf.get_rect(topleft=(x, y))
            self.word_items.append(
                {
                    "rect": rect,
                    "token": token,
                    "key": key,
                    "is_target": is_target,
                    "is_found": is_found,
                    "surface": surf,
                }
            )
            self.text_surface.blit(surf, rect)
            x += w + space_w

    def handle_click(self, pos):
        local_pos = (pos[0] - self.text_pos[0], pos[1] - self.text_pos[1])

        for item in self.word_items:
            if (
                item["is_target"]
                and not item["is_found"]
                and item["rect"].collidepoint(local_pos)
            ):
                event_bus.emit(
                    "TargetWordClicked",
                    word=item["key"],
                    blaber=self,
                )
                return True
        return False

    def update(self, dt):
        if self.blinking:
            self.blink_time += dt
            if self.blink_time >= self.blink_duration:
                self.blink_time = 0
                self.blinking = False

    def draw(self, screen):
        pygame.draw.circle(screen, self.skin_color, self.head_pos, self.head_size)

        if not self.blinking:
            pygame.draw.circle(
                screen,
                self.eye_color,
                (self.head_pos[0] - 12, self.head_pos[1] - 6),
                self.head_size // 6,
            )
            pygame.draw.circle(
                screen,
                self.eye_color,
                (self.head_pos[0] + 12, self.head_pos[1] - 6),
                self.head_size // 6,
            )
        else:
            pygame.draw.circle(
                screen,
                self.skin_color,
                (self.head_pos[0] - 12, self.head_pos[1] - 6),
                self.head_size // 6,
            )
            pygame.draw.circle(
                screen,
                self.skin_color,
                (self.head_pos[0] + 12, self.head_pos[1] - 6),
                self.head_size // 6,
            )

        box_rect = pygame.Rect(self.text_pos, self.text_size)
        screen.blit(self.text_surface, self.text_pos)
        pygame.draw.rect(screen, (160, 160, 160), box_rect, 2)


class BlaberRegistry:
    def __init__(self):
        self.blabers = []

    def add_blaber(self, blaber):
        self.blabers.append(blaber)


class BlaberFactory:
    def __init__(self, registry, ui_manager):
        self.registry = registry
        self.ui_manager = ui_manager
        self.blaber_data = {
            "dracula": {
                "head_pos": (80, 200),
                "head_size": 40,
                "text_pos": (160, 40),
                "text_size": (140, 200),
                "text_origin": DRACULA_BLABER,
                "ui_manager": self.ui_manager,
            },
            "ulysses": {
                "head_pos": (380, 200),
                "head_size": 40,
                "text_pos": (460, 40),
                "text_size": (140, 200),
                "text_origin": ULYSSES_BLABER,
                "ui_manager": self.ui_manager,
            },
            "sherlock": {
                "head_pos": (680, 200),
                "head_size": 40,
                "text_pos": (760, 40),
                "text_size": (140, 200),
                "text_origin": SHERLOCK_BLABER,
                "ui_manager": self.ui_manager,
            },
        }

        self.create_blabers()

    def create_blabers(self):
        for _, blaber in self.blaber_data.items():
            self.registry.add_blaber(Blaber(**blaber))


class BlabersManager:
    def __init__(self, ui_manager):
        self.blaber_registry = BlaberRegistry()
        self.ui_manager = ui_manager
        self.blaber_factory = BlaberFactory(self.blaber_registry, self.ui_manager)

        event_bus.subscribe("GenerateTextRequest", self.on_generate_text_request)
        event_bus.subscribe("TargetWordClicked", self.on_target_word_clicked)
        event_bus.subscribe("WordFound", self.on_word_found)
        event_bus.subscribe("RestartGameRequest", self.on_restart_request)

    def on_generate_text_request(self):
        for blaber in self.blaber_registry.blabers:
            blaber.update_text_box()

    def on_target_word_clicked(self, word, blaber):
        blaber.blinking = True

    def on_word_found(self, words):
        for blaber in self.blaber_registry.blabers:
            blaber.set_found_words(words)

    def on_restart_request(self):
        for blaber in self.blaber_registry.blabers:
            blaber.text_linker.set_found_words(set())
            blaber.update_text_box()

    def update(self, dt):
        for blaber in self.blaber_registry.blabers:
            blaber.update(dt)

    def draw(self, screen):
        for blaber in self.blaber_registry.blabers:
            blaber.draw(screen)


class WordSearchUI:
    def __init__(self, target_words, ui_manager):
        self.target_words = target_words
        self.ui_manager = ui_manager
        self.round_won = False
        self.found_words = set()
        self.win_count = 0

        self.font = pygame.font.Font(None, 28)
        self.small_font = pygame.font.Font(None, 22)

        event_bus.subscribe("WordFound", self.on_word_found)
        event_bus.subscribe("RoundWon", self.on_round_won)
        event_bus.subscribe("RestartGameRequest", self.on_restart_request)

    def on_word_found(self, words):
        if self.round_won:
            return

        self.found_words = set(words)

        if set(words) >= set(self.target_words):
            self.round_won = True

    def on_round_won(self, wins):
        self.round_won = True
        self.win_count = wins

    def on_restart_request(self):
        self.round_won = False
        self.found_words = set()

    def draw(self, screen):
        panel = pygame.Rect(0, 320, SCREEN_WIDTH, 220)
        pygame.draw.rect(screen, (235, 235, 235), panel)
        pygame.draw.rect(screen, (180, 180, 180), panel, 2)

        title = self.small_font.render("TARGET WORDS", True, (30, 30, 30))
        screen.blit(title, (20, 332))

        x = 20
        y = 366

        for word in self.target_words:
            is_found = word in self.found_words
            color = (33, 189, 0) if is_found else (255, 41, 0)
            text = self.font.render(word.upper(), True, color)
            box = text.get_rect(topleft=(x, y))
            box.inflate_ip(20, 12)

            pygame.draw.rect(screen, (250, 250, 250), box, border_radius=6)
            pygame.draw.rect(screen, color, box, 2, border_radius=6)
            screen.blit(text, (box.x + 10, box.y + 6))

            x += box.width + 16

        if self.round_won:
            win_text = self.font.render("YOU'VE WON", True, (30, 30, 30))
            screen.blit(win_text, (20, 420))

        wins_text = self.font.render(f"WINS: {self.win_count}", True, (30, 30, 30))
        screen.blit(wins_text, (794, 408))


class GameState:
    def __init__(self, target_words):
        self.target_words = target_words
        self.words_found = set()
        self.wins = 0
        self.round_won = False
        event_bus.subscribe("RestartGameRequest", self.on_restart_request)

    def mark_found(self, word):
        if word in self.target_words:
            self.words_found.add(word)
            event_bus.emit("WordFound", words=self.words_found)

        if self.has_won() and not self.round_won:
            self.wins += 1
            event_bus.emit("RoundWon", wins=self.wins)
            self.round_won = True

    def on_restart_request(self):
        self.target_words = TARGET_WORDS
        self.round_won = False
        self.words_found = set()

    def has_won(self):
        return self.words_found >= set(self.target_words)


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()

        self.game_state = GameState(TARGET_WORDS)

        # Keep pygame_gui only for the buttons.
        # No custom theme or custom font loading here.
        self.ui_manager = pygame_gui.UIManager((SCREEN_WIDTH, SCREEN_HEIGHT))

        self.blaber_manager = BlabersManager(self.ui_manager)
        self.words_search_ui = WordSearchUI(TARGET_WORDS, self.ui_manager)

        event_bus.subscribe(
            "TargetWordClicked",
            lambda word, blaber: self.game_state.mark_found(word),
        )

        self.generate_text_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect(792, 328, 160, 80),
            text="GENERATE TEXT",
            manager=self.ui_manager,
        )

        self.restart_game_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect(792, 452, 160, 80),
            text="RESTART GAME",
            manager=self.ui_manager,
        )

    def update(self, dt):
        self.blaber_manager.update(dt)
        self.ui_manager.update(dt)

    def draw(self):
        self.screen.fill((255, 255, 255))
        self.blaber_manager.draw(self.screen)
        self.words_search_ui.draw(self.screen)
        self.ui_manager.draw_ui(self.screen)
        pygame.display.flip()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    raise SystemExit

                self.ui_manager.process_events(event)

                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    event_bus.emit("GenerateTextRequest")

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for blaber in self.blaber_manager.blaber_registry.blabers:
                        if blaber.handle_click(event.pos):
                            break

                if event.type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element == self.generate_text_button:
                        event_bus.emit("GenerateTextRequest")

                    if event.ui_element == self.restart_game_button:
                        event_bus.emit("RestartGameRequest")

            dt = self.clock.tick(FPS) / 1000.0
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)


game = Game()
asyncio.run(game.run())